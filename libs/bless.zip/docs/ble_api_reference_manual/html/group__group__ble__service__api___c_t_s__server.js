var group__group__ble__service__api___c_t_s__server =
[
    [ "Cy_BLE_CTSS_SetCharacteristicValue", "group__group__ble__service__api___c_t_s__server.html#gaffc4cf2f00726866f75ee6ed4c948e44", null ],
    [ "Cy_BLE_CTSS_GetCharacteristicValue", "group__group__ble__service__api___c_t_s__server.html#gadbb5e6ef6696e1b5b1ee632594469234", null ],
    [ "Cy_BLE_CTSS_GetCharacteristicDescriptor", "group__group__ble__service__api___c_t_s__server.html#ga2c8b772f8e71b0932dfc51f94b41d570", null ],
    [ "Cy_BLE_CTSS_SendNotification", "group__group__ble__service__api___c_t_s__server.html#gae82e9a5c295437e5a960dd976df15ce2", null ]
];