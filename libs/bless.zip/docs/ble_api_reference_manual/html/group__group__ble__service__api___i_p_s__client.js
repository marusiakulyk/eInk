var group__group__ble__service__api___i_p_s__client =
[
    [ "Cy_BLE_IPSC_SetCharacteristicValueWithoutResponse", "group__group__ble__service__api___i_p_s__client.html#gaecfcdcea50275d6a33d10baa6f20b601", null ],
    [ "Cy_BLE_IPSC_SetCharacteristicValue", "group__group__ble__service__api___i_p_s__client.html#gaeea6e613a290f89d2d0a4b5866fcf89d", null ],
    [ "Cy_BLE_IPSC_ReliableWriteCharacteristicValue", "group__group__ble__service__api___i_p_s__client.html#gab2c18ca8a8aadaba791ad7c31569cdfc", null ],
    [ "Cy_BLE_IPSC_GetCharacteristicValue", "group__group__ble__service__api___i_p_s__client.html#ga3b0cb4e0a8388aa529fa955e7857aee3", null ],
    [ "Cy_BLE_IPSC_GetMultipleCharacteristicValues", "group__group__ble__service__api___i_p_s__client.html#ga28af79328086213cfebd8a3d106040b1", null ],
    [ "Cy_BLE_IPSC_GetLongCharacteristicValue", "group__group__ble__service__api___i_p_s__client.html#gae96192f9e5ce4801e8a1af3969941a17", null ],
    [ "Cy_BLE_IPSC_SetCharacteristicDescriptor", "group__group__ble__service__api___i_p_s__client.html#ga9c882b821fc51a749cf33faa4a20e3a3", null ],
    [ "Cy_BLE_IPSC_GetCharacteristicDescriptor", "group__group__ble__service__api___i_p_s__client.html#ga906b917f639837f4509cb17276fcd02b", null ]
];