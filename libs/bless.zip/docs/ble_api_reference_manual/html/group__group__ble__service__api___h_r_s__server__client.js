var group__group__ble__service__api___h_r_s__server__client =
[
    [ "Cy_BLE_HRSS_Init", "group__group__ble__service__api___h_r_s__server__client.html#gaa401011acfa82d81b14c69c956261e2a", null ],
    [ "Cy_BLE_HRSC_Init", "group__group__ble__service__api___h_r_s__server__client.html#gad7499f2275515c557f9925a4965cd9fc", null ],
    [ "Cy_BLE_HRS_RegisterAttrCallback", "group__group__ble__service__api___h_r_s__server__client.html#ga57edd4bb4c9832742a4707b299da42a0", null ]
];