var group__group__ble__service__api___h_p_s__client =
[
    [ "Cy_BLE_HPSC_SetCharacteristicValue", "group__group__ble__service__api___h_p_s__client.html#ga10e5d5275c182d0912488449f495d8e8", null ],
    [ "Cy_BLE_HPSC_GetCharacteristicValue", "group__group__ble__service__api___h_p_s__client.html#ga50549f723f52f2911caee7f78332af7f", null ],
    [ "Cy_BLE_HPSC_SetLongCharacteristicValue", "group__group__ble__service__api___h_p_s__client.html#ga7ae07190c2c62462cb53cd37d9d0ba13", null ],
    [ "Cy_BLE_HPSC_GetLongCharacteristicValue", "group__group__ble__service__api___h_p_s__client.html#ga7eb43a535906cb1c18b98e8e08bb2669", null ],
    [ "Cy_BLE_HPSC_SetCharacteristicDescriptor", "group__group__ble__service__api___h_p_s__client.html#ga92e0b120fe74d5c303c393cf0ddb6e06", null ],
    [ "Cy_BLE_HPSC_GetCharacteristicDescriptor", "group__group__ble__service__api___h_p_s__client.html#ga0a93e94b0a1703047050181ee5c22fdf", null ]
];