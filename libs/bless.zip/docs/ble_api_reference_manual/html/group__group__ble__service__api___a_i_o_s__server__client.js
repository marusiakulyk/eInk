var group__group__ble__service__api___a_i_o_s__server__client =
[
    [ "Cy_BLE_AIOSS_Init", "group__group__ble__service__api___a_i_o_s__server__client.html#gaf8c42c28d747beb0b65049f9ffe38686", null ],
    [ "Cy_BLE_AIOSC_Init", "group__group__ble__service__api___a_i_o_s__server__client.html#gaad9621ee9cc43a1028384d8e8bff582e", null ],
    [ "Cy_BLE_AIOS_RegisterAttrCallback", "group__group__ble__service__api___a_i_o_s__server__client.html#ga2c24ba5147109f6cfa5efc7c7e67115a", null ]
];