var group__group__ble__service__api___l_l_s__definitions =
[
    [ "cy_stc_ble_lls_char_value_t", "structcy__stc__ble__lls__char__value__t.html", [
      [ "connHandle", "structcy__stc__ble__lls__char__value__t.html#a7d23f645818fc153a9f3a58887b011a4", null ],
      [ "charIndex", "structcy__stc__ble__lls__char__value__t.html#a3e918b4c35f80cfee3cd3f0cfbb25c7f", null ],
      [ "value", "structcy__stc__ble__lls__char__value__t.html#a5697aba39405d125c71f787597a80cbe", null ]
    ] ],
    [ "cy_stc_ble_llss_t", "structcy__stc__ble__llss__t.html", [
      [ "serviceHandle", "structcy__stc__ble__llss__t.html#aa4f9b5ea86359525bb9e672b19c6cf4f", null ],
      [ "alertLevelCharHandle", "structcy__stc__ble__llss__t.html#ad55c5a2743509fc42d00d5ff05493e57", null ]
    ] ],
    [ "cy_stc_ble_llsc_t", "structcy__stc__ble__llsc__t.html", [
      [ "alertLevelChar", "structcy__stc__ble__llsc__t.html#a3b3654c4453c207fd60e792b19967374", null ]
    ] ],
    [ "cy_stc_ble_llss_config_t", "structcy__stc__ble__llss__config__t.html", [
      [ "attrInfo", "structcy__stc__ble__llss__config__t.html#ae97911aadecafac4e426004f1544be5c", null ]
    ] ],
    [ "cy_stc_ble_llsc_config_t", "structcy__stc__ble__llsc__config__t.html", [
      [ "attrInfo", "structcy__stc__ble__llsc__config__t.html#ab4a7e28595d682489fbd95483670ca22", null ],
      [ "serviceDiscIdx", "structcy__stc__ble__llsc__config__t.html#a535d1140f8e98a9ff020250c750ac818", null ]
    ] ],
    [ "cy_en_ble_lls_char_index_t", "group__group__ble__service__api___l_l_s__definitions.html#ga82ac6d64078f6e873783dc62305a4055", [
      [ "CY_BLE_LLS_ALERT_LEVEL", "group__group__ble__service__api___l_l_s__definitions.html#gga82ac6d64078f6e873783dc62305a4055a27fbefe88096a20fc9ade8b47bea0740", null ],
      [ "CY_BLE_LLS_CHAR_COUNT", "group__group__ble__service__api___l_l_s__definitions.html#gga82ac6d64078f6e873783dc62305a4055a96f99356024de897b80e755b8ee250c3", null ]
    ] ]
];