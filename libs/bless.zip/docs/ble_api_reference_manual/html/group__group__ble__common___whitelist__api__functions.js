var group__group__ble__common___whitelist__api__functions =
[
    [ "Cy_BLE_AddDeviceToWhiteList", "group__group__ble__common___whitelist__api__functions.html#ga6e2997c70484c232096b5efed77a8315", null ],
    [ "Cy_BLE_RemoveDeviceFromWhiteList", "group__group__ble__common___whitelist__api__functions.html#gaa603b221c8208a4b924d0131d307e09f", null ],
    [ "Cy_BLE_GetWhiteList", "group__group__ble__common___whitelist__api__functions.html#ga4fea1efaf71f4490a00a8f88eb3297bd", null ]
];