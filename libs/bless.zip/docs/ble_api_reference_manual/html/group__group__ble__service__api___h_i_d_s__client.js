var group__group__ble__service__api___h_i_d_s__client =
[
    [ "Cy_BLE_HIDSC_SetCharacteristicValue", "group__group__ble__service__api___h_i_d_s__client.html#gad3f38dd6881f6117ed524b9a5cffe891", null ],
    [ "Cy_BLE_HIDSC_GetCharacteristicValue", "group__group__ble__service__api___h_i_d_s__client.html#gafb1823acc1a7b6aae63906144d7d70c2", null ],
    [ "Cy_BLE_HIDSC_SetCharacteristicDescriptor", "group__group__ble__service__api___h_i_d_s__client.html#gaad80093c8aab2ebe6ca1d3d8cae898e8", null ],
    [ "Cy_BLE_HIDSC_GetCharacteristicDescriptor", "group__group__ble__service__api___h_i_d_s__client.html#ga1cc04f8e933a2eedf183d05e6c56d8d9", null ]
];