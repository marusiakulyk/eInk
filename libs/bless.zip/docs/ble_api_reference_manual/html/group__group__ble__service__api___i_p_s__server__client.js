var group__group__ble__service__api___i_p_s__server__client =
[
    [ "Cy_BLE_IPSS_Init", "group__group__ble__service__api___i_p_s__server__client.html#ga4bfc05be47eb50dacbaea4965490d6e8", null ],
    [ "Cy_BLE_IPSC_Init", "group__group__ble__service__api___i_p_s__server__client.html#gae5ce92bfb986fb20544115922e84fe80", null ],
    [ "Cy_BLE_IPS_RegisterAttrCallback", "group__group__ble__service__api___i_p_s__server__client.html#gadff7078265a62b7b08a82e41513fc0a2", null ]
];