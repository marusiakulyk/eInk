var group__group__ble__service__api___b_l_s =
[
    [ "BLS Server and Client Function", "group__group__ble__service__api___b_l_s__server__client.html", "group__group__ble__service__api___b_l_s__server__client" ],
    [ "BLS Server Functions", "group__group__ble__service__api___b_l_s__server.html", "group__group__ble__service__api___b_l_s__server" ],
    [ "BLS Client Functions", "group__group__ble__service__api___b_l_s__client.html", "group__group__ble__service__api___b_l_s__client" ],
    [ "BLS Definitions and Data Structures", "group__group__ble__service__api___b_l_s__definitions.html", "group__group__ble__service__api___b_l_s__definitions" ]
];