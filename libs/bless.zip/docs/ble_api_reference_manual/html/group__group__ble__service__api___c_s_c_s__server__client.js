var group__group__ble__service__api___c_s_c_s__server__client =
[
    [ "Cy_BLE_CSCSS_Init", "group__group__ble__service__api___c_s_c_s__server__client.html#ga987102e252fad5103a92651850b2b165", null ],
    [ "Cy_BLE_CSCSC_Init", "group__group__ble__service__api___c_s_c_s__server__client.html#ga2144ddea0b89fec163b49a1f3c376853", null ],
    [ "Cy_BLE_CSCS_RegisterAttrCallback", "group__group__ble__service__api___c_s_c_s__server__client.html#gac53c280acaaf43852c73e1ec8f4f9601", null ]
];