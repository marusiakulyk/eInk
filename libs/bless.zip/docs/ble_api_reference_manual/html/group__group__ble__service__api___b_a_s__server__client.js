var group__group__ble__service__api___b_a_s__server__client =
[
    [ "Cy_BLE_BASS_Init", "group__group__ble__service__api___b_a_s__server__client.html#ga6d9fc4306181340e158ad7f3a05c0f1a", null ],
    [ "Cy_BLE_BASC_Init", "group__group__ble__service__api___b_a_s__server__client.html#gadd8eb161ffe80a67e13918dab2389f86", null ],
    [ "Cy_BLE_BAS_RegisterAttrCallback", "group__group__ble__service__api___b_a_s__server__client.html#ga27afae675db5f9d2fc33392af3fd9037", null ]
];