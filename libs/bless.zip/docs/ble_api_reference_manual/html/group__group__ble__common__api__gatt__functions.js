var group__group__ble__common__api__gatt__functions =
[
    [ "Cy_BLE_GATT_GetBusyStatus", "group__group__ble__common__api__gatt__functions.html#gabe19ddf74bbc0b62180a1ea33f3d8553", null ],
    [ "Cy_BLE_GATT_GetMtuSize", "group__group__ble__common__api__gatt__functions.html#ga7e4e6930c3f705c2f9a1638a53ed7c45", null ]
];