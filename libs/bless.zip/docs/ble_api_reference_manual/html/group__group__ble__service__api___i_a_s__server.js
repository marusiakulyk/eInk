var group__group__ble__service__api___i_a_s__server =
[
    [ "Cy_BLE_IASS_GetCharacteristicValue", "group__group__ble__service__api___i_a_s__server.html#ga1898e12f1c143f416553829d42b04089", null ]
];