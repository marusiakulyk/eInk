var group__group__ble__service__api___b_a_s__server =
[
    [ "Cy_BLE_BASS_SetCharacteristicValue", "group__group__ble__service__api___b_a_s__server.html#gafb15a710d14910571235cd4ec9289d77", null ],
    [ "Cy_BLE_BASS_GetCharacteristicValue", "group__group__ble__service__api___b_a_s__server.html#gad19706bf22d1c3bc139bb939abd5f6f2", null ],
    [ "Cy_BLE_BASS_GetCharacteristicDescriptor", "group__group__ble__service__api___b_a_s__server.html#ga219b624fd0aac139882ad33181fd1860", null ],
    [ "Cy_BLE_BASS_SendNotification", "group__group__ble__service__api___b_a_s__server.html#gab8de4cfd6a5b99804d8a21dcb0d45c0f", null ]
];