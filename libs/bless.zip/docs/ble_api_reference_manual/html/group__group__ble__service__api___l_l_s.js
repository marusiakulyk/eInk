var group__group__ble__service__api___l_l_s =
[
    [ "LLS Server and Client Function", "group__group__ble__service__api___l_l_s__server__client.html", "group__group__ble__service__api___l_l_s__server__client" ],
    [ "LLS Server Functions", "group__group__ble__service__api___l_l_s__server.html", "group__group__ble__service__api___l_l_s__server" ],
    [ "LLS Client Functions", "group__group__ble__service__api___l_l_s__client.html", "group__group__ble__service__api___l_l_s__client" ],
    [ "LLS Definitions and Data Structures", "group__group__ble__service__api___l_l_s__definitions.html", "group__group__ble__service__api___l_l_s__definitions" ]
];