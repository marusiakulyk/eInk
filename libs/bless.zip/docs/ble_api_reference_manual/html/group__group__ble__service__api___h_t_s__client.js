var group__group__ble__service__api___h_t_s__client =
[
    [ "Cy_BLE_HTSC_SetCharacteristicValue", "group__group__ble__service__api___h_t_s__client.html#ga901520f374d86fa223f7adb6b0cac3a0", null ],
    [ "Cy_BLE_HTSC_GetCharacteristicValue", "group__group__ble__service__api___h_t_s__client.html#ga0e4f9d0d2a48f71a1ea1472449596d04", null ],
    [ "Cy_BLE_HTSC_SetCharacteristicDescriptor", "group__group__ble__service__api___h_t_s__client.html#gab132a820d2a47505f0efeccd8ebc3cca", null ],
    [ "Cy_BLE_HTSC_GetCharacteristicDescriptor", "group__group__ble__service__api___h_t_s__client.html#ga97184b4ad3ae9862b7f1a13ed88ddc9d", null ]
];