var group__group__ble__service__api___a_n_s__server__client =
[
    [ "Cy_BLE_ANSS_Init", "group__group__ble__service__api___a_n_s__server__client.html#ga09f20135ce014488b17178ef22b88f16", null ],
    [ "Cy_BLE_ANSC_Init", "group__group__ble__service__api___a_n_s__server__client.html#gaf6fcd5f02744f5d66f4e78d44999dfc6", null ],
    [ "Cy_BLE_ANS_RegisterAttrCallback", "group__group__ble__service__api___a_n_s__server__client.html#ga67b5d1e739ce9b23ba46accb113b1faa", null ]
];