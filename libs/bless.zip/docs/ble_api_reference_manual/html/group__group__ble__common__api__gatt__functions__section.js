var group__group__ble__common__api__gatt__functions__section =
[
    [ "GATT Client and Server Functions", "group__group__ble__common__api__gatt__functions.html", "group__group__ble__common__api__gatt__functions" ],
    [ "GATT Client Functions", "group__group__ble__common__api__gatt__client__functions.html", "group__group__ble__common__api__gatt__client__functions" ],
    [ "GATT Server Functions", "group__group__ble__common__api__gatt__server__functions.html", "group__group__ble__common__api__gatt__server__functions" ]
];