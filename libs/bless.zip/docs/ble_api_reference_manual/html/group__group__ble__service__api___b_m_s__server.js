var group__group__ble__service__api___b_m_s__server =
[
    [ "Cy_BLE_BMSS_SetCharacteristicValue", "group__group__ble__service__api___b_m_s__server.html#ga0e5766e088c160a0664e3d3a715bb715", null ],
    [ "Cy_BLE_BMSS_GetCharacteristicValue", "group__group__ble__service__api___b_m_s__server.html#ga42c62fd50955344d36ed5bf1ed2bc834", null ],
    [ "Cy_BLE_BMSS_SetCharacteristicDescriptor", "group__group__ble__service__api___b_m_s__server.html#ga8edc67133c0d96b7e878f69d2929d711", null ],
    [ "Cy_BLE_BMSS_GetCharacteristicDescriptor", "group__group__ble__service__api___b_m_s__server.html#ga63d2f09c60b54ad5dc93071d81e82a6a", null ]
];