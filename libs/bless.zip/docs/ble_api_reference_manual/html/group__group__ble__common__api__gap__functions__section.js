var group__group__ble__common__api__gap__functions__section =
[
    [ "GAP Central and Peripheral Functions", "group__group__ble__common__api__gap__functions.html", "group__group__ble__common__api__gap__functions" ],
    [ "GAP Central Functions", "group__group__ble__common__api__gap__central__functions.html", "group__group__ble__common__api__gap__central__functions" ],
    [ "GAP Peripheral Functions", "group__group__ble__common__api__gap__peripheral__functions.html", "group__group__ble__common__api__gap__peripheral__functions" ]
];