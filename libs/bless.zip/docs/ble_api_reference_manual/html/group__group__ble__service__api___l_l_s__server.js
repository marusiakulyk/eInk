var group__group__ble__service__api___l_l_s__server =
[
    [ "Cy_BLE_LLSS_GetCharacteristicValue", "group__group__ble__service__api___l_l_s__server.html#gab69f0c57e4e8744309b046c716a936e7", null ]
];