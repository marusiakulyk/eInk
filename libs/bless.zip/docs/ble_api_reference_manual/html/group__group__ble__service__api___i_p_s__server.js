var group__group__ble__service__api___i_p_s__server =
[
    [ "Cy_BLE_IPSS_SetCharacteristicValue", "group__group__ble__service__api___i_p_s__server.html#gab32babd1cb415368a3b3e6ea97015f3e", null ],
    [ "Cy_BLE_IPSS_GetCharacteristicValue", "group__group__ble__service__api___i_p_s__server.html#ga8844fedb5bcb4e24d8383bb71511bc8b", null ],
    [ "Cy_BLE_IPSS_SetCharacteristicDescriptor", "group__group__ble__service__api___i_p_s__server.html#ga0688da4ba4bdcc1f454b0fa75327d1a8", null ],
    [ "Cy_BLE_IPSS_GetCharacteristicDescriptor", "group__group__ble__service__api___i_p_s__server.html#ga6c75a04f99a7ff5e4db8942e3a5eecbd", null ]
];