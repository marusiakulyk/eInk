var group__group__ble__service__api___a_i_o_s__client =
[
    [ "Cy_BLE_AIOSC_SetCharacteristicValueWithoutResponse", "group__group__ble__service__api___a_i_o_s__client.html#ga7e52574d9f084f5fa76450182ccd5c9e", null ],
    [ "Cy_BLE_AIOSC_SetCharacteristicValue", "group__group__ble__service__api___a_i_o_s__client.html#gab5153aa36feeece9362f14240cabfe5b", null ],
    [ "Cy_BLE_AIOSC_GetCharacteristicValue", "group__group__ble__service__api___a_i_o_s__client.html#ga8c4aaa69b493fb5f606942f6cb956586", null ],
    [ "Cy_BLE_AIOSC_SetCharacteristicDescriptor", "group__group__ble__service__api___a_i_o_s__client.html#ga1c1b64dfd0c664a3afafd1d906bbdf59", null ],
    [ "Cy_BLE_AIOSC_GetCharacteristicDescriptor", "group__group__ble__service__api___a_i_o_s__client.html#gaf1d06605638bc15f05f6e8060bf6e005", null ]
];