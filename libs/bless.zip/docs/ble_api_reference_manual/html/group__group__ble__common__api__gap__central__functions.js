var group__group__ble__common__api__gap__central__functions =
[
    [ "Cy_BLE_GAPC_StartScan", "group__group__ble__common__api__gap__central__functions.html#ga06ad7c5a0f265897c0f8a9d1f79695b4", null ],
    [ "Cy_BLE_GAPC_StopScan", "group__group__ble__common__api__gap__central__functions.html#gaf05df8db69912fcab86883b2618eb66e", null ],
    [ "Cy_BLE_GAPC_ConnectDevice", "group__group__ble__common__api__gap__central__functions.html#ga76386b6b464a3783f190157202db9b82", null ],
    [ "Cy_BLE_GAPC_CancelDeviceConnection", "group__group__ble__common__api__gap__central__functions.html#ga8405648f65b8364ad8cc77521c7a8e36", null ],
    [ "Cy_BLE_GAPC_ResolveDevice", "group__group__ble__common__api__gap__central__functions.html#gad34d0337e5353d3f60dcc5aeaa31b9fb", null ],
    [ "Cy_BLE_GAPC_SetRemoteAddr", "group__group__ble__common__api__gap__central__functions.html#gada4e13c47119514e3573b70e5c014605", null ],
    [ "Cy_BLE_GAPC_ConnectionParamUpdateRequest", "group__group__ble__common__api__gap__central__functions.html#ga6cb851d11763ced036a1e41cd0a4b707", null ]
];