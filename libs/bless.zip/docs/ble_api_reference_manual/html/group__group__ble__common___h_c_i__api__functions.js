var group__group__ble__common___h_c_i__api__functions =
[
    [ "Cy_BLE_SoftHciSendAppPkt", "group__group__ble__common___h_c_i__api__functions.html#ga2963d8a11c1aac9442e171e6e33e34fb", null ],
    [ "Cy_BLE_RegisterHciCb", "group__group__ble__common___h_c_i__api__functions.html#ga1651ae819f69544defe83d426b90d900", null ],
    [ "Cy_BLE_HciShutdown", "group__group__ble__common___h_c_i__api__functions.html#ga11b6e316b6df61ac9bd5740e1809eed3", null ],
    [ "Cy_BLE_HciTransmit", "group__group__ble__common___h_c_i__api__functions.html#ga11cd19bb7216532af621ab4d838cc7d4", null ]
];