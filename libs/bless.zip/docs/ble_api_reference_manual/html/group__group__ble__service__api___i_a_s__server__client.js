var group__group__ble__service__api___i_a_s__server__client =
[
    [ "Cy_BLE_IASS_Init", "group__group__ble__service__api___i_a_s__server__client.html#gab58ba8c97a2fbf3ada43dc9f27c53e8f", null ],
    [ "Cy_BLE_IASC_Init", "group__group__ble__service__api___i_a_s__server__client.html#ga0b9879a7cc0b9b69a37d8a3e2a5e6e78", null ],
    [ "Cy_BLE_IAS_RegisterAttrCallback", "group__group__ble__service__api___i_a_s__server__client.html#ga5eaefdb8aace72fb807a01ae2dcffc50", null ]
];