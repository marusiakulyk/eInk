var group__group__ble__common__api__macros__section =
[
    [ "Common", "group__group__ble__common__api__macros.html", "group__group__ble__common__api__macros" ],
    [ "BLE GATT Database", "group__group__ble__common__api__macros__gatt__db.html", "group__group__ble__common__api__macros__gatt__db" ],
    [ "BLE Services UUID", "group__group__ble__common__api__macros__gatt__uuid__services.html", null ],
    [ "BLE GATT Attribute Types UUID", "group__group__ble__common__api__macros__gatt__uuid__char__gatt__type.html", "group__group__ble__common__api__macros__gatt__uuid__char__gatt__type" ],
    [ "BLE GATT Characteristic Descriptors UUID", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html", "group__group__ble__common__api__macros__gatt__uuid__char__desc" ],
    [ "BLE GATT Characteristic Types UUID", "group__group__ble__common__api__macros__gatt__uuid__char__type.html", "group__group__ble__common__api__macros__gatt__uuid__char__type" ],
    [ "BLE Appearance values", "group__group__ble__common__api__macros__appearance__values.html", "group__group__ble__common__api__macros__appearance__values" ]
];