var group__group__ble__service__api___b_a_s =
[
    [ "BAS Server and Client Function", "group__group__ble__service__api___b_a_s__server__client.html", "group__group__ble__service__api___b_a_s__server__client" ],
    [ "BAS Server Functions", "group__group__ble__service__api___b_a_s__server.html", "group__group__ble__service__api___b_a_s__server" ],
    [ "BAS Client Functions", "group__group__ble__service__api___b_a_s__client.html", "group__group__ble__service__api___b_a_s__client" ],
    [ "BAS Definitions and Data Structures", "group__group__ble__service__api___b_a_s__definitions.html", "group__group__ble__service__api___b_a_s__definitions" ]
];