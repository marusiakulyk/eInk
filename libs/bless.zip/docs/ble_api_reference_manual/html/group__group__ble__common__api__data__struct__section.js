var group__group__ble__common__api__data__struct__section =
[
    [ "Common", "group__group__ble__common__api__definitions.html", "group__group__ble__common__api__definitions" ],
    [ "GAP", "group__group__ble__common__api__gap__definitions.html", "group__group__ble__common__api__gap__definitions" ],
    [ "GATT", "group__group__ble__common__api__gatt__definitions.html", "group__group__ble__common__api__gatt__definitions" ],
    [ "L2CAP", "group__group__ble__common__api__l2cap__definitions.html", "group__group__ble__common__api__l2cap__definitions" ]
];