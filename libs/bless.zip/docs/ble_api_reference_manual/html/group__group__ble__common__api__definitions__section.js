var group__group__ble__common__api__definitions__section =
[
    [ "BLE Error Code", "group__group__ble__common__macros__error.html", "group__group__ble__common__macros__error" ],
    [ "Macros", "group__group__ble__common__api__macros__section.html", "group__group__ble__common__api__macros__section" ],
    [ "Data Structures", "group__group__ble__common__api__data__struct__section.html", "group__group__ble__common__api__data__struct__section" ]
];