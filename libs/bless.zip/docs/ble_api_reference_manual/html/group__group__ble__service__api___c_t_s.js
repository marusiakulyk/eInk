var group__group__ble__service__api___c_t_s =
[
    [ "CTS Server and Client Function", "group__group__ble__service__api___c_t_s__server__client.html", "group__group__ble__service__api___c_t_s__server__client" ],
    [ "CTS Server Functions", "group__group__ble__service__api___c_t_s__server.html", "group__group__ble__service__api___c_t_s__server" ],
    [ "CTS Client Functions", "group__group__ble__service__api___c_t_s__client.html", "group__group__ble__service__api___c_t_s__client" ],
    [ "CTS Definitions and Data Structures", "group__group__ble__service__api___c_t_s__definitions.html", "group__group__ble__service__api___c_t_s__definitions" ]
];