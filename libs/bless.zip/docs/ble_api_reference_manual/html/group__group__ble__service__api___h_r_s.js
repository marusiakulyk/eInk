var group__group__ble__service__api___h_r_s =
[
    [ "HRS Server and Client Function", "group__group__ble__service__api___h_r_s__server__client.html", "group__group__ble__service__api___h_r_s__server__client" ],
    [ "HRS Server Functions", "group__group__ble__service__api___h_r_s__server.html", "group__group__ble__service__api___h_r_s__server" ],
    [ "HRS Client Functions", "group__group__ble__service__api___h_r_s__client.html", "group__group__ble__service__api___h_r_s__client" ],
    [ "HRS Definitions and Data Structures", "group__group__ble__service__api___h_r_s__definitions.html", "group__group__ble__service__api___h_r_s__definitions" ]
];