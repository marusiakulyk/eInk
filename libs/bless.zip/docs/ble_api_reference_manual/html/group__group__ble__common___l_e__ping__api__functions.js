var group__group__ble__common___l_e__ping__api__functions =
[
    [ "Cy_BLE_WriteAuthPayloadTimeout", "group__group__ble__common___l_e__ping__api__functions.html#ga73992891218af1afb1d713f93b5df81e", null ],
    [ "Cy_BLE_ReadAuthPayloadTimeout", "group__group__ble__common___l_e__ping__api__functions.html#gaeb9f4591e67ecca71bad862fb38b9d47", null ]
];