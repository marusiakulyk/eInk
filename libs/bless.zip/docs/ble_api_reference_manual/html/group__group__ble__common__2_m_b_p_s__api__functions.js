var group__group__ble__common__2_m_b_p_s__api__functions =
[
    [ "Cy_BLE_SetPhy", "group__group__ble__common__2_m_b_p_s__api__functions.html#ga1ab7f2b6b620562d022dfc0c8a236a77", null ],
    [ "Cy_BLE_GetPhy", "group__group__ble__common__2_m_b_p_s__api__functions.html#ga6d34707dd73f2bb52c722311e934aa88", null ]
];