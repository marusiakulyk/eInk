var group__group__ble__service__api___e_s_s__server__client =
[
    [ "Cy_BLE_ESSS_Init", "group__group__ble__service__api___e_s_s__server__client.html#ga60513cc70d52b21b64d5705d4a7e0149", null ],
    [ "Cy_BLE_ESSC_Init", "group__group__ble__service__api___e_s_s__server__client.html#ga6004453c90d75d4a3fd69a2030fcfe4a", null ],
    [ "Cy_BLE_ESS_RegisterAttrCallback", "group__group__ble__service__api___e_s_s__server__client.html#gafab32c13ee560576eb997f372d3a2fdd", null ]
];