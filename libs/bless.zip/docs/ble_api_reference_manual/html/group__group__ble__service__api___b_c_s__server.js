var group__group__ble__service__api___b_c_s__server =
[
    [ "Cy_BLE_BCSS_SetCharacteristicValue", "group__group__ble__service__api___b_c_s__server.html#ga72968c4b5354c03f2655798a1a9bdb09", null ],
    [ "Cy_BLE_BCSS_GetCharacteristicValue", "group__group__ble__service__api___b_c_s__server.html#gafdded1eb6faeea10758551d08007ddba", null ],
    [ "Cy_BLE_BCSS_SetCharacteristicDescriptor", "group__group__ble__service__api___b_c_s__server.html#ga527701ef31c10722f32043d2ddc9b875", null ],
    [ "Cy_BLE_BCSS_GetCharacteristicDescriptor", "group__group__ble__service__api___b_c_s__server.html#ga9f7d8646ca2b0f9b0de487c2ef9305a3", null ],
    [ "Cy_BLE_BCSS_SendIndication", "group__group__ble__service__api___b_c_s__server.html#ga320ebc12f5d024e61ddef9429bbc1320", null ]
];