var group__group__ble__service__api___l_n_s__client =
[
    [ "Cy_BLE_LNSC_SetCharacteristicValue", "group__group__ble__service__api___l_n_s__client.html#ga83ced34d28df76a68b4f513617906710", null ],
    [ "Cy_BLE_LNSC_GetCharacteristicValue", "group__group__ble__service__api___l_n_s__client.html#ga5a12aa396283f9555d5855a12621f1cc", null ],
    [ "Cy_BLE_LNSC_SetCharacteristicDescriptor", "group__group__ble__service__api___l_n_s__client.html#ga3b9599eca7bd85abe4400973871750c4", null ],
    [ "Cy_BLE_LNSC_GetCharacteristicDescriptor", "group__group__ble__service__api___l_n_s__client.html#ga32bbea02b6e6913eb9c533b89e20b561", null ]
];