var group__group__ble__service__api___e_s_s__client =
[
    [ "Cy_BLE_ESSC_SetCharacteristicValue", "group__group__ble__service__api___e_s_s__client.html#gab61213b25656fde1da9ba82250a2efed", null ],
    [ "Cy_BLE_ESSC_GetCharacteristicValue", "group__group__ble__service__api___e_s_s__client.html#gaa6662b1b9278a53873a76c1705009155", null ],
    [ "Cy_BLE_ESSC_SetCharacteristicDescriptor", "group__group__ble__service__api___e_s_s__client.html#ga8edabee0ef330bc41657b53cf4e438dc", null ],
    [ "Cy_BLE_ESSC_GetCharacteristicDescriptor", "group__group__ble__service__api___e_s_s__client.html#ga8de32232dee9a67416ebb2680563571e", null ],
    [ "Cy_BLE_ESSC_SetLongCharacteristicDescriptor", "group__group__ble__service__api___e_s_s__client.html#ga7a317333637ea81119c128000bb548b5", null ],
    [ "Cy_BLE_ESSC_GetLongCharacteristicDescriptor", "group__group__ble__service__api___e_s_s__client.html#ga33b02f4a38799fcad054c8c971eb2e37", null ]
];