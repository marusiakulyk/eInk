var group__group__ble__common__api__macros__gatt__uuid__char__gatt__type =
[
    [ "CY_BLE_UUID_PRIMARY_SERVICE", "group__group__ble__common__api__macros__gatt__uuid__char__gatt__type.html#ga07b00bb13634fe3c08fd21eaddfd8320", null ],
    [ "CY_BLE_UUID_SECONDARY_SERVICE", "group__group__ble__common__api__macros__gatt__uuid__char__gatt__type.html#ga881e499db44453dedfade567fe4c3e2c", null ],
    [ "CY_BLE_UUID_INCLUDE", "group__group__ble__common__api__macros__gatt__uuid__char__gatt__type.html#ga053895350936c3df344274eaa119ee53", null ],
    [ "CY_BLE_UUID_CHARACTERISTIC", "group__group__ble__common__api__macros__gatt__uuid__char__gatt__type.html#ga848ebcf671022253e05120565ae08a81", null ]
];