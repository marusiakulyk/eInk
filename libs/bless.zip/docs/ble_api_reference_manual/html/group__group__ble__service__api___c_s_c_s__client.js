var group__group__ble__service__api___c_s_c_s__client =
[
    [ "Cy_BLE_CSCSC_SetCharacteristicValue", "group__group__ble__service__api___c_s_c_s__client.html#ga5e6bc608170a34e2d7696b91a119debc", null ],
    [ "Cy_BLE_CSCSC_GetCharacteristicValue", "group__group__ble__service__api___c_s_c_s__client.html#ga735bb87e59d42113b85f0926bf61bf4e", null ],
    [ "Cy_BLE_CSCSC_SetCharacteristicDescriptor", "group__group__ble__service__api___c_s_c_s__client.html#gaedbb17a3bd7ffb3c23674c21cac7948d", null ],
    [ "Cy_BLE_CSCSC_GetCharacteristicDescriptor", "group__group__ble__service__api___c_s_c_s__client.html#ga69e0b53b3be5ce3987760b948f8b281e", null ],
    [ "Cy_BLE_CSCSC_StoreProfileData", "group__group__ble__service__api___c_s_c_s__client.html#gac440ae6d958145e650f788e8cc3be33f", null ]
];