var group__group__ble__service__api___b_l_s__server =
[
    [ "Cy_BLE_BLSS_SetCharacteristicValue", "group__group__ble__service__api___b_l_s__server.html#ga950a85ce6e08f3b9d8411dbcdac33e43", null ],
    [ "Cy_BLE_BLSS_GetCharacteristicValue", "group__group__ble__service__api___b_l_s__server.html#ga6f794f01f65bb67c78582f473266d652", null ],
    [ "Cy_BLE_BLSS_GetCharacteristicDescriptor", "group__group__ble__service__api___b_l_s__server.html#ga43dd0abc73153cf81be41c776785cf08", null ],
    [ "Cy_BLE_BLSS_SendNotification", "group__group__ble__service__api___b_l_s__server.html#ga4ab4c1b8c5ab933ef3de653073edcded", null ],
    [ "Cy_BLE_BLSS_SendIndication", "group__group__ble__service__api___b_l_s__server.html#ga843bf2193b2f04fbffa748854f3b3175", null ]
];