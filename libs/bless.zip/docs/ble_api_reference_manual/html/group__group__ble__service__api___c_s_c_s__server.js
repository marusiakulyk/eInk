var group__group__ble__service__api___c_s_c_s__server =
[
    [ "Cy_BLE_CSCSS_SetCharacteristicValue", "group__group__ble__service__api___c_s_c_s__server.html#ga9254adbe5a3fc35f2b99dec6bf96f742", null ],
    [ "Cy_BLE_CSCSS_GetCharacteristicValue", "group__group__ble__service__api___c_s_c_s__server.html#ga0a972a9cb2c09b5206a175e061635d39", null ],
    [ "Cy_BLE_CSCSS_GetCharacteristicDescriptor", "group__group__ble__service__api___c_s_c_s__server.html#gaa5f67a26459a74f15acbb7f8706f561a", null ],
    [ "Cy_BLE_CSCSS_SendNotification", "group__group__ble__service__api___c_s_c_s__server.html#gacd705d8d443d4da15d1918eb1dce8986", null ],
    [ "Cy_BLE_CSCSS_SendIndication", "group__group__ble__service__api___c_s_c_s__server.html#ga15b53129a764df0f53be9391b680b7aa", null ]
];