var group__group__ble__common__api__gatt__server__functions =
[
    [ "Cy_BLE_GATTS_WriteAttributeValuePeer", "group__group__ble__common__api__gatt__server__functions.html#ga83833a69e752df584bf934e657269b6b", null ],
    [ "Cy_BLE_GATTS_WriteAttributeValueLocal", "group__group__ble__common__api__gatt__server__functions.html#ga95db4f1380702b6b24efeef544cb1502", null ],
    [ "Cy_BLE_GATTS_ReadAttributeValueLocal", "group__group__ble__common__api__gatt__server__functions.html#ga27fc940942188f1bb26364ab21a77bed", null ],
    [ "Cy_BLE_GATTS_ReadAttributeValuePeer", "group__group__ble__common__api__gatt__server__functions.html#ga6297d202cdac41fb65d63fd57f8c529c", null ],
    [ "Cy_BLE_GATTS_SendNotification", "group__group__ble__common__api__gatt__server__functions.html#gaf52c8c5d584562649b4c02bdb4673790", null ],
    [ "Cy_BLE_GATTS_SendIndication", "group__group__ble__common__api__gatt__server__functions.html#ga8f9c0c5d189db93aa25f9368059f1672", null ],
    [ "Cy_BLE_GATTS_IsNotificationEnabled", "group__group__ble__common__api__gatt__server__functions.html#gac49f73eea18ed60ffc71ff218f664ae7", null ],
    [ "Cy_BLE_GATTS_IsIndicationEnabled", "group__group__ble__common__api__gatt__server__functions.html#ga5637f7d1c98396861fa5473aaa0e4935", null ],
    [ "Cy_BLE_GATTS_SendErrorRsp", "group__group__ble__common__api__gatt__server__functions.html#ga144da11ae3b06cec1d3d52b669ce7882", null ],
    [ "Cy_BLE_GATTS_EnableAttribute", "group__group__ble__common__api__gatt__server__functions.html#gafbfef0c6dd5a996d5b343d83c98683fd", null ],
    [ "Cy_BLE_GATTS_DisableAttribute", "group__group__ble__common__api__gatt__server__functions.html#gade79e0b447fbde3a5ec91402136a1377", null ],
    [ "Cy_BLE_GATTS_DbAuthorize", "group__group__ble__common__api__gatt__server__functions.html#ga2b4aa01b5cba0b8a236fbc6a59d89cad", null ],
    [ "Cy_BLE_GATTS_WriteRsp", "group__group__ble__common__api__gatt__server__functions.html#gab1ec6315d61671ac47fbd3f34e28ddca", null ]
];