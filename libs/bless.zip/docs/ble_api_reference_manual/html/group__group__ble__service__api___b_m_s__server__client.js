var group__group__ble__service__api___b_m_s__server__client =
[
    [ "Cy_BLE_BMSS_Init", "group__group__ble__service__api___b_m_s__server__client.html#ga03306530af37e0612a4624b03655b5ab", null ],
    [ "Cy_BLE_BMSC_Init", "group__group__ble__service__api___b_m_s__server__client.html#gaecaf74ebd332ee941ad83dd48e8bb954", null ],
    [ "Cy_BLE_BMS_RegisterAttrCallback", "group__group__ble__service__api___b_m_s__server__client.html#gadc173324d820a75e1eae97f80631f2e2", null ]
];