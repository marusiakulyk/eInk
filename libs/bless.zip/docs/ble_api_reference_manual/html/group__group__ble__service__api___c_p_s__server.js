var group__group__ble__service__api___c_p_s__server =
[
    [ "Cy_BLE_CPSS_SetCharacteristicValue", "group__group__ble__service__api___c_p_s__server.html#ga1aeeaabcdcbe170f95f4f951f8d7db57", null ],
    [ "Cy_BLE_CPSS_GetCharacteristicValue", "group__group__ble__service__api___c_p_s__server.html#gae084b83b3b06bf851a37ade9a897bcdb", null ],
    [ "Cy_BLE_CPSS_SetCharacteristicDescriptor", "group__group__ble__service__api___c_p_s__server.html#ga118430b8d289bd13e230794aa8e951f1", null ],
    [ "Cy_BLE_CPSS_GetCharacteristicDescriptor", "group__group__ble__service__api___c_p_s__server.html#ga1c57f418921bd0ccb1bdf379bbe786aa", null ],
    [ "Cy_BLE_CPSS_SendNotification", "group__group__ble__service__api___c_p_s__server.html#ga834377c32177322e085a80454de36810", null ],
    [ "Cy_BLE_CPSS_SendIndication", "group__group__ble__service__api___c_p_s__server.html#ga3bc05b4d1617cb2ae8767ff7500a88e9", null ],
    [ "Cy_BLE_CPSS_StartBroadcast", "group__group__ble__service__api___c_p_s__server.html#ga1752bd353b59a587c99bda963ca23872", null ],
    [ "Cy_BLE_CPSS_StopBroadcast", "group__group__ble__service__api___c_p_s__server.html#ga2c3afcc504f2106dcaaec0e48f483f05", null ]
];