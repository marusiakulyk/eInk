var group__group__ble__service__api___a_n_c_s__server =
[
    [ "Cy_BLE_ANCSS_SetCharacteristicValue", "group__group__ble__service__api___a_n_c_s__server.html#gab1c800e6820927c10db517cf788ba21c", null ],
    [ "Cy_BLE_ANCSS_GetCharacteristicValue", "group__group__ble__service__api___a_n_c_s__server.html#ga9fcd9cca5a080774bafa00a64b2e1428", null ],
    [ "Cy_BLE_ANCSS_GetCharacteristicDescriptor", "group__group__ble__service__api___a_n_c_s__server.html#ga33b11a630dd1c858a2680754dcccc2fb", null ],
    [ "Cy_BLE_ANCSS_SendNotification", "group__group__ble__service__api___a_n_c_s__server.html#ga4d110f11ad8adde92f2a8f429b9a1af7", null ]
];