var group__group__ble__service__api___c_g_m_s__client =
[
    [ "Cy_BLE_CGMSC_SetCharacteristicValue", "group__group__ble__service__api___c_g_m_s__client.html#gaf65927c05aee7a72c467857da9616a4e", null ],
    [ "Cy_BLE_CGMSC_GetCharacteristicValue", "group__group__ble__service__api___c_g_m_s__client.html#gae82b8f864bab53dab75e0cc4a424f773", null ],
    [ "Cy_BLE_CGMSC_SetCharacteristicDescriptor", "group__group__ble__service__api___c_g_m_s__client.html#ga60982a3cfc4f73c43478e58aa32d0279", null ],
    [ "Cy_BLE_CGMSC_GetCharacteristicDescriptor", "group__group__ble__service__api___c_g_m_s__client.html#ga67660698cf4d435f77852ba62492d262", null ]
];