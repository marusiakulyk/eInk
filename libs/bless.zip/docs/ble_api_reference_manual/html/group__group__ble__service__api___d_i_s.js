var group__group__ble__service__api___d_i_s =
[
    [ "DIS Server and Client Function", "group__group__ble__service__api___d_i_s__server__client.html", "group__group__ble__service__api___d_i_s__server__client" ],
    [ "DIS Server Functions", "group__group__ble__service__api___d_i_s__server.html", "group__group__ble__service__api___d_i_s__server" ],
    [ "DIS Client Functions", "group__group__ble__service__api___d_i_s__client.html", "group__group__ble__service__api___d_i_s__client" ],
    [ "DIS Definitions and Data Structures", "group__group__ble__service__api___d_i_s__definitions.html", "group__group__ble__service__api___d_i_s__definitions" ]
];