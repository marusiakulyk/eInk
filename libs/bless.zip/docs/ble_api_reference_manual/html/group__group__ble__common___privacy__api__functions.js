var group__group__ble__common___privacy__api__functions =
[
    [ "Cy_BLE_EnablePrivacyFeature", "group__group__ble__common___privacy__api__functions.html#ga1af3cff0a1f7d1a9db155314e5562bf1", null ],
    [ "Cy_BLE_AddDeviceToResolvingList", "group__group__ble__common___privacy__api__functions.html#gac9ddc6e93c6a2dbb1d682070a8a342d0", null ],
    [ "Cy_BLE_GetPeerResolvableAddress", "group__group__ble__common___privacy__api__functions.html#ga58a0baf4b8757c9f45bdfb1ae6bc1cda", null ],
    [ "Cy_BLE_GetLocalResolvableAddress", "group__group__ble__common___privacy__api__functions.html#ga4729002c9067d5fb4f87d51041135d65", null ],
    [ "Cy_BLE_RemoveDeviceFromResolvingList", "group__group__ble__common___privacy__api__functions.html#ga04d4ef8a28ad902f43ad2c5c2d20ae70", null ],
    [ "Cy_BLE_SetResolvablePvtAddressTimeOut", "group__group__ble__common___privacy__api__functions.html#gafc88c86977186d3f76da9c31e7c2c5fb", null ],
    [ "Cy_BLE_SetAddressResolutionEnable", "group__group__ble__common___privacy__api__functions.html#gade3580de2d6223d3baa46c920088a6d7", null ],
    [ "Cy_BLE_GetResolvingList", "group__group__ble__common___privacy__api__functions.html#ga85a1f1abec1007bd257d2cccc335cfc1", null ],
    [ "Cy_BLE_SetPrivacyMode", "group__group__ble__common___privacy__api__functions.html#gab05e6757dba80c0e3f530de5b0e185bd", null ]
];