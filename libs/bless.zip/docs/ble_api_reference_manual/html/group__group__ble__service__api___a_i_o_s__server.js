var group__group__ble__service__api___a_i_o_s__server =
[
    [ "Cy_BLE_AIOSS_SetCharacteristicValue", "group__group__ble__service__api___a_i_o_s__server.html#ga258ed0e2ddd0f24ca94c048c6a588e10", null ],
    [ "Cy_BLE_AIOSS_GetCharacteristicValue", "group__group__ble__service__api___a_i_o_s__server.html#ga843d5f7be24cd2b97129bc86a8b9534f", null ],
    [ "Cy_BLE_AIOSS_SetCharacteristicDescriptor", "group__group__ble__service__api___a_i_o_s__server.html#ga6ecc07223cfd89edd12e0bde2feda2ce", null ],
    [ "Cy_BLE_AIOSS_GetCharacteristicDescriptor", "group__group__ble__service__api___a_i_o_s__server.html#ga52834f6d3e59baec735a27948469c67f", null ],
    [ "Cy_BLE_AIOSS_SendNotification", "group__group__ble__service__api___a_i_o_s__server.html#gaff2c31e73ef7a166cf51865bf75e5472", null ],
    [ "Cy_BLE_AIOSS_SendIndication", "group__group__ble__service__api___a_i_o_s__server.html#ga9dc056b7b62301b4d9ec2914109876bd", null ]
];