var group__group__ble__service__api___c_p_s__client =
[
    [ "Cy_BLE_CPSC_SetCharacteristicValue", "group__group__ble__service__api___c_p_s__client.html#ga1788b5ea985045ec7bc1b77e3125f31e", null ],
    [ "Cy_BLE_CPSC_GetCharacteristicValue", "group__group__ble__service__api___c_p_s__client.html#ga4fc0c6ef3fb55ce388c213df4e576fe9", null ],
    [ "Cy_BLE_CPSC_SetCharacteristicDescriptor", "group__group__ble__service__api___c_p_s__client.html#gaa26abf66733e7c67beef2186d6dd142f", null ],
    [ "Cy_BLE_CPSC_GetCharacteristicDescriptor", "group__group__ble__service__api___c_p_s__client.html#ga85ceffb6f812f174fc0c0066e0bf5bf4", null ],
    [ "Cy_BLE_CPSC_StartObserve", "group__group__ble__service__api___c_p_s__client.html#ga7747b84cd12e21ccf7d04b8ad844ef96", null ],
    [ "Cy_BLE_CPSC_StopObserve", "group__group__ble__service__api___c_p_s__client.html#ga6672d2a71927bcf078ec45d9e0d54f89", null ]
];