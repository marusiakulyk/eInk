var group__group__ble__common__api__global__variables =
[
    [ "cy_ble_pendingFlashWrite", "group__group__ble__common__api__global__variables.html#gac02274681ded14ecefb86e6d7623fdcc", null ]
];