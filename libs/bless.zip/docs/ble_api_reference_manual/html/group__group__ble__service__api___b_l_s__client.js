var group__group__ble__service__api___b_l_s__client =
[
    [ "Cy_BLE_BLSC_GetCharacteristicValue", "group__group__ble__service__api___b_l_s__client.html#gaa0c67cad74a0867aa3f7d99e1e8434f2", null ],
    [ "Cy_BLE_BLSC_SetCharacteristicDescriptor", "group__group__ble__service__api___b_l_s__client.html#ga671cda04f08a4df882c1e30f0ebbf0aa", null ],
    [ "Cy_BLE_BLSC_GetCharacteristicDescriptor", "group__group__ble__service__api___b_l_s__client.html#ga893ff22bcbb0117de2aa983c1ec834db", null ]
];