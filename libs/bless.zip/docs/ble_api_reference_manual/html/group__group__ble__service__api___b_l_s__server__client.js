var group__group__ble__service__api___b_l_s__server__client =
[
    [ "Cy_BLE_BLSS_Init", "group__group__ble__service__api___b_l_s__server__client.html#ga1053720b71d68ea69e78db04fc6de552", null ],
    [ "Cy_BLE_BLSC_Init", "group__group__ble__service__api___b_l_s__server__client.html#ga804e4cc9c2173358d704973639af59cb", null ],
    [ "Cy_BLE_BLS_RegisterAttrCallback", "group__group__ble__service__api___b_l_s__server__client.html#ga47ccd1c32e977503c4531b1ba18eefa6", null ]
];