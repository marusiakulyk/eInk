var group__group__ble__common__api__gap__peripheral__functions =
[
    [ "Cy_BLE_GAPP_StartAdvertisement", "group__group__ble__common__api__gap__peripheral__functions.html#gac26286c502401fc1bb3c9561b66733d7", null ],
    [ "Cy_BLE_GAPP_StopAdvertisement", "group__group__ble__common__api__gap__peripheral__functions.html#gaade80c72779aac513475bb76374c8ad2", null ],
    [ "Cy_BLE_GAPP_UpdateAdvScanData", "group__group__ble__common__api__gap__peripheral__functions.html#gabb8ab6894ec553068f75d5f81a95aeda", null ],
    [ "Cy_BLE_GAPP_AuthReqReply", "group__group__ble__common__api__gap__peripheral__functions.html#gafd058b11ddcf322f0389c51917465334", null ]
];