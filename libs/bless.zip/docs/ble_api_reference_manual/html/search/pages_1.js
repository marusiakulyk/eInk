var searchData=
[
  ['general_20description',['General Description',['../page_ble_general.html',1,'']]]
];
