var searchData=
[
  ['industry_20standards',['Industry Standards',['../page_ble_section_indastry_standards.html',1,'']]]
];
