var searchData=
[
  ['scan_20parameters_20service_20_28scps_29',['Scan Parameters Service (ScPS)',['../group__group__ble__service__api___s_c_p_s.html',1,'']]],
  ['scps_20client_20functions',['ScPS Client Functions',['../group__group__ble__service__api___s_c_p_s__client.html',1,'']]],
  ['scps_20definitions_20and_20data_20structures',['ScPS Definitions and Data Structures',['../group__group__ble__service__api___s_c_p_s__definitions.html',1,'']]],
  ['scps_20server_20functions',['ScPS Server Functions',['../group__group__ble__service__api___s_c_p_s__server.html',1,'']]],
  ['scps_20server_20and_20client_20functions',['ScPS Server and Client Functions',['../group__group__ble__service__api___s_c_p_s__server__client.html',1,'']]]
];
