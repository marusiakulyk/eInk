var searchData=
[
  ['phone_20alert_20status_20service_20_28pass_29',['Phone Alert Status Service (PASS)',['../group__group__ble__service__api___p_a_s_s.html',1,'']]],
  ['pass_20client_20functions',['PASS Client Functions',['../group__group__ble__service__api___p_a_s_s__client.html',1,'']]],
  ['pass_20definitions_20and_20data_20structures',['PASS Definitions and Data Structures',['../group__group__ble__service__api___p_a_s_s__definitions.html',1,'']]],
  ['pass_20server_20functions',['PASS Server Functions',['../group__group__ble__service__api___p_a_s_s__server.html',1,'']]],
  ['pass_20server_20and_20client_20function',['PASS Server and Client Function',['../group__group__ble__service__api___p_a_s_s__server__client.html',1,'']]],
  ['pulse_20oximeter_20service_20_28plxs_29',['Pulse Oximeter Service (PLXS)',['../group__group__ble__service__api___p_l_x_s.html',1,'']]],
  ['plxs_20client_20functions',['PLXS Client Functions',['../group__group__ble__service__api___p_l_x_s__client.html',1,'']]],
  ['plxs_20definitions_20and_20data_20structures',['PLXS Definitions and Data Structures',['../group__group__ble__service__api___p_l_x_s__definitions.html',1,'']]],
  ['plxs_20server_20functions',['PLXS Server Functions',['../group__group__ble__service__api___p_l_x_s__server.html',1,'']]],
  ['plxs_20server_20and_20client_20function',['PLXS Server and Client Function',['../group__group__ble__service__api___p_l_x_s__server__client.html',1,'']]]
];
