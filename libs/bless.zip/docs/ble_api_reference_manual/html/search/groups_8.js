var searchData=
[
  ['immediate_20alert_20service_20_28ias_29',['Immediate Alert Service (IAS)',['../group__group__ble__service__api___i_a_s.html',1,'']]],
  ['ias_20client_20functions',['IAS Client Functions',['../group__group__ble__service__api___i_a_s__client.html',1,'']]],
  ['ias_20definitions_20and_20data_20structures',['IAS Definitions and Data Structures',['../group__group__ble__service__api___i_a_s__definitions.html',1,'']]],
  ['ias_20server_20functions',['IAS Server Functions',['../group__group__ble__service__api___i_a_s__server.html',1,'']]],
  ['ias_20server_20and_20client_20function',['IAS Server and Client Function',['../group__group__ble__service__api___i_a_s__server__client.html',1,'']]],
  ['indoor_20positioning_20service_20_28ips_29',['Indoor Positioning Service (IPS)',['../group__group__ble__service__api___i_p_s.html',1,'']]],
  ['ips_20client_20functions',['IPS Client Functions',['../group__group__ble__service__api___i_p_s__client.html',1,'']]],
  ['ips_20definitions_20and_20data_20structures',['IPS Definitions and Data Structures',['../group__group__ble__service__api___i_p_s__definitions.html',1,'']]],
  ['ips_20server_20functions',['IPS Server Functions',['../group__group__ble__service__api___i_p_s__server.html',1,'']]],
  ['ips_20server_20and_20client_20function',['IPS Server and Client Function',['../group__group__ble__service__api___i_p_s__server__client.html',1,'']]]
];
