var searchData=
[
  ['queuebuffer',['queueBuffer',['../structcy__stc__ble__prepare__write__request__memory__t.html#a421f2f3d00bd6f88b03e936bbb95a6f5',1,'cy_stc_ble_prepare_write_request_memory_t']]]
];
