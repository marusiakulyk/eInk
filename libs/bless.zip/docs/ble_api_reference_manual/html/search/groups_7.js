var searchData=
[
  ['hid_20service_20_28hids_29',['HID Service (HIDS)',['../group__group__ble__service__api___h_i_d_s.html',1,'']]],
  ['hids_20client_20functions',['HIDS Client Functions',['../group__group__ble__service__api___h_i_d_s__client.html',1,'']]],
  ['hids_20definitions_20and_20data_20structures',['HIDS Definitions and Data Structures',['../group__group__ble__service__api___h_i_d_s__definitions.html',1,'']]],
  ['hids_20server_20functions',['HIDS Server Functions',['../group__group__ble__service__api___h_i_d_s__server.html',1,'']]],
  ['hids_20server_20and_20client_20functions',['HIDS Server and Client Functions',['../group__group__ble__service__api___h_i_d_s__server__client.html',1,'']]],
  ['http_20proxy_20service_20_28hps_29',['HTTP Proxy Service (HPS)',['../group__group__ble__service__api___h_p_s.html',1,'']]],
  ['hps_20client_20functions',['HPS Client Functions',['../group__group__ble__service__api___h_p_s__client.html',1,'']]],
  ['hps_20definitions_20and_20data_20structures',['HPS Definitions and Data Structures',['../group__group__ble__service__api___h_p_s__definitions.html',1,'']]],
  ['hps_20server_20functions',['HPS Server Functions',['../group__group__ble__service__api___h_p_s__server.html',1,'']]],
  ['hps_20server_20and_20client_20function',['HPS Server and Client Function',['../group__group__ble__service__api___h_p_s__server__client.html',1,'']]],
  ['heart_20rate_20service_20_28hrs_29',['Heart Rate Service (HRS)',['../group__group__ble__service__api___h_r_s.html',1,'']]],
  ['hrs_20client_20functions',['HRS Client Functions',['../group__group__ble__service__api___h_r_s__client.html',1,'']]],
  ['hrs_20definitions_20and_20data_20structures',['HRS Definitions and Data Structures',['../group__group__ble__service__api___h_r_s__definitions.html',1,'']]],
  ['hrs_20server_20functions',['HRS Server Functions',['../group__group__ble__service__api___h_r_s__server.html',1,'']]],
  ['hrs_20server_20and_20client_20function',['HRS Server and Client Function',['../group__group__ble__service__api___h_r_s__server__client.html',1,'']]],
  ['health_20thermometer_20service_20_28hts_29',['Health Thermometer Service (HTS)',['../group__group__ble__service__api___h_t_s.html',1,'']]],
  ['hts_20client_20functions',['HTS Client Functions',['../group__group__ble__service__api___h_t_s__client.html',1,'']]],
  ['hts_20definitions_20and_20data_20structures',['HTS Definitions and Data Structures',['../group__group__ble__service__api___h_t_s__definitions.html',1,'']]],
  ['hts_20server_20functions',['HTS Server Functions',['../group__group__ble__service__api___h_t_s__server.html',1,'']]],
  ['hts_20server_20and_20client_20function',['HTS Server and Client Function',['../group__group__ble__service__api___h_t_s__server__client.html',1,'']]]
];
