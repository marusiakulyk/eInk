var searchData=
[
  ['next_20dst_20change_20service_20_28ndcs_29',['Next DST Change Service (NDCS)',['../group__group__ble__service__api___n_d_c_s.html',1,'']]],
  ['ndcs_20client_20functions',['NDCS Client Functions',['../group__group__ble__service__api___n_d_c_s__client.html',1,'']]],
  ['ndcs_20definitions_20and_20data_20structures',['NDCS Definitions and Data Structures',['../group__group__ble__service__api___n_d_c_s__definitions.html',1,'']]],
  ['ndcs_20server_20functions',['NDCS Server Functions',['../group__group__ble__service__api___n_d_c_s__server.html',1,'']]],
  ['ndcs_20server_20and_20client_20functions',['NDCS Server and Client Functions',['../group__group__ble__service__api___n_d_c_s__server__client.html',1,'']]]
];
