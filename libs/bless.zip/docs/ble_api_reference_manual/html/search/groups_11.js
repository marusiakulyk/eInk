var searchData=
[
  ['whitelist_20api',['Whitelist API',['../group__group__ble__common___whitelist__api__functions.html',1,'']]],
  ['wireless_20power_20transfer_20service_20_28wpts_29',['Wireless Power Transfer Service (WPTS)',['../group__group__ble__service__api___w_p_t_s.html',1,'']]],
  ['wpts_20client_20functions',['WPTS Client Functions',['../group__group__ble__service__api___w_p_t_s__client.html',1,'']]],
  ['wpts_20definitions_20and_20data_20structures',['WPTS Definitions and Data Structures',['../group__group__ble__service__api___w_p_t_s__definitions.html',1,'']]],
  ['wpts_20server_20functions',['WPTS Server Functions',['../group__group__ble__service__api___w_p_t_s__server.html',1,'']]],
  ['wpts_20server_20and_20client_20function',['WPTS Server and Client Function',['../group__group__ble__service__api___w_p_t_s__server__client.html',1,'']]],
  ['weight_20scale_20service_20_28wss_29',['Weight Scale Service (WSS)',['../group__group__ble__service__api___w_s_s.html',1,'']]],
  ['wss_20client_20functions',['WSS Client Functions',['../group__group__ble__service__api___w_s_s__client.html',1,'']]],
  ['wss_20definitions_20and_20data_20structures',['WSS Definitions and Data Structures',['../group__group__ble__service__api___w_s_s__definitions.html',1,'']]],
  ['wss_20server_20functions',['WSS Server Functions',['../group__group__ble__service__api___w_s_s__server.html',1,'']]],
  ['wss_20server_20and_20client_20function',['WSS Server and Client Function',['../group__group__ble__service__api___w_s_s__server__client.html',1,'']]]
];
