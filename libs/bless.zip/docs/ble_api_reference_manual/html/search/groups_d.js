var searchData=
[
  ['running_20speed_20and_20cadence_20service_20_28rscs_29',['Running Speed and Cadence Service (RSCS)',['../group__group__ble__service__api___r_s_c_s.html',1,'']]],
  ['rscs_20client_20functions',['RSCS Client Functions',['../group__group__ble__service__api___r_s_c_s__client.html',1,'']]],
  ['rscs_20definitions_20and_20data_20structures',['RSCS Definitions and Data Structures',['../group__group__ble__service__api___r_s_c_s__definitions.html',1,'']]],
  ['rscs_20server_20functions',['RSCS Server Functions',['../group__group__ble__service__api___r_s_c_s__server.html',1,'']]],
  ['rscs_20server_20and_20client_20functions',['RSCS Server and Client Functions',['../group__group__ble__service__api___r_s_c_s__server__client.html',1,'']]],
  ['reference_20time_20update_20service_20_28rtus_29',['Reference Time Update Service (RTUS)',['../group__group__ble__service__api___r_t_u_s.html',1,'']]],
  ['rtus_20client_20functions',['RTUS Client Functions',['../group__group__ble__service__api___r_t_u_s__client.html',1,'']]],
  ['rtus_20definitions_20and_20data_20structures',['RTUS Definitions and Data Structures',['../group__group__ble__service__api___r_t_u_s__definitions.html',1,'']]],
  ['rtus_20server_20functions',['RTUS Server Functions',['../group__group__ble__service__api___r_t_u_s__server.html',1,'']]],
  ['rtus_20server_20and_20client_20function',['RTUS Server and Client Function',['../group__group__ble__service__api___r_t_u_s__server__client.html',1,'']]]
];
