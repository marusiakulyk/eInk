var searchData=
[
  ['2mbps_20feature_20api',['2Mbps Feature API',['../group__group__ble__common__2_m_b_p_s__api__functions.html',1,'']]]
];
