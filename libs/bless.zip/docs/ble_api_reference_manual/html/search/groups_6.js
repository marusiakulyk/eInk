var searchData=
[
  ['gap_20central_20functions',['GAP Central Functions',['../group__group__ble__common__api__gap__central__functions.html',1,'']]],
  ['gap',['GAP',['../group__group__ble__common__api__gap__definitions.html',1,'']]],
  ['gap_20central_20and_20peripheral_20functions',['GAP Central and Peripheral Functions',['../group__group__ble__common__api__gap__functions.html',1,'']]],
  ['gap_20functions',['GAP Functions',['../group__group__ble__common__api__gap__functions__section.html',1,'']]],
  ['gap_20peripheral_20functions',['GAP Peripheral Functions',['../group__group__ble__common__api__gap__peripheral__functions.html',1,'']]],
  ['gatt_20client_20functions',['GATT Client Functions',['../group__group__ble__common__api__gatt__client__functions.html',1,'']]],
  ['gatt',['GATT',['../group__group__ble__common__api__gatt__definitions.html',1,'']]],
  ['gatt_20client_20and_20server_20functions',['GATT Client and Server Functions',['../group__group__ble__common__api__gatt__functions.html',1,'']]],
  ['gatt_20functions',['GATT Functions',['../group__group__ble__common__api__gatt__functions__section.html',1,'']]],
  ['gatt_20server_20functions',['GATT Server Functions',['../group__group__ble__common__api__gatt__server__functions.html',1,'']]],
  ['global_20variables',['Global Variables',['../group__group__ble__common__api__global__variables.html',1,'']]],
  ['glucose_20service_20_28gls_29',['Glucose Service (GLS)',['../group__group__ble__service__api___g_l_s.html',1,'']]],
  ['gls_20client_20functions',['GLS Client Functions',['../group__group__ble__service__api___g_l_s__client.html',1,'']]],
  ['gls_20definitions_20and_20data_20structures',['GLS Definitions and Data Structures',['../group__group__ble__service__api___g_l_s__definitions.html',1,'']]],
  ['gls_20server_20functions',['GLS Server Functions',['../group__group__ble__service__api___g_l_s__server.html',1,'']]],
  ['gls_20server_20and_20client_20function',['GLS Server and Client Function',['../group__group__ble__service__api___g_l_s__server__client.html',1,'']]]
];
