var searchData=
[
  ['data_20structures',['Data Structures',['../group__group__ble__common__api__data__struct__section.html',1,'']]],
  ['data_20length_20extension_20_28dle_29_20api',['Data Length Extension (DLE) API',['../group__group__ble__common___data__length__extension__api__functions.html',1,'']]],
  ['device_20information_20service_20_28dis_29',['Device Information Service (DIS)',['../group__group__ble__service__api___d_i_s.html',1,'']]],
  ['dis_20client_20functions',['DIS Client Functions',['../group__group__ble__service__api___d_i_s__client.html',1,'']]],
  ['dis_20definitions_20and_20data_20structures',['DIS Definitions and Data Structures',['../group__group__ble__service__api___d_i_s__definitions.html',1,'']]],
  ['dis_20server_20functions',['DIS Server Functions',['../group__group__ble__service__api___d_i_s__server.html',1,'']]],
  ['dis_20server_20and_20client_20function',['DIS Server and Client Function',['../group__group__ble__service__api___d_i_s__server__client.html',1,'']]]
];
