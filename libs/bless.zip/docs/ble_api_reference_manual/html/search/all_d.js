var searchData=
[
  ['next_20dst_20change_20service_20_28ndcs_29',['Next DST Change Service (NDCS)',['../group__group__ble__service__api___n_d_c_s.html',1,'']]],
  ['ndcs_20client_20functions',['NDCS Client Functions',['../group__group__ble__service__api___n_d_c_s__client.html',1,'']]],
  ['ndcs_20definitions_20and_20data_20structures',['NDCS Definitions and Data Structures',['../group__group__ble__service__api___n_d_c_s__definitions.html',1,'']]],
  ['ndcs_20server_20functions',['NDCS Server Functions',['../group__group__ble__service__api___n_d_c_s__server.html',1,'']]],
  ['ndcs_20server_20and_20client_20functions',['NDCS Server and Client Functions',['../group__group__ble__service__api___n_d_c_s__server__client.html',1,'']]],
  ['nonce',['nonce',['../structcy__stc__ble__aes__ccm__encrypt__info__t.html#aeec150318efd3c9b6a5d2a62d642a1a1',1,'cy_stc_ble_aes_ccm_encrypt_info_t::nonce()'],['../structcy__stc__ble__aes__ccm__decrypt__info__t.html#ab088f8562cbd1fd6f60a0881fe5c286b',1,'cy_stc_ble_aes_ccm_decrypt_info_t::nonce()']]],
  ['noofdevices',['noOfDevices',['../structcy__stc__ble__gap__bonded__device__list__info__t.html#a39c8530ce15c1694958a2c7d304e8dc9',1,'cy_stc_ble_gap_bonded_device_list_info_t']]],
  ['notificationtype',['notificationType',['../structcy__stc__ble__gap__sc__kp__notif__info__t.html#a431ef13da49a92ad72c28af11946e55a',1,'cy_stc_ble_gap_sc_kp_notif_info_t']]],
  ['numofrequests',['numOfRequests',['../structcy__stc__ble__gattc__reliable__write__req__t.html#af990e6d92a1030a5fdb5220de60eaad2',1,'cy_stc_ble_gattc_reliable_write_req_t']]]
];
