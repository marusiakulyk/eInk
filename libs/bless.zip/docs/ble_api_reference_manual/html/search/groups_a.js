var searchData=
[
  ['macros',['Macros',['../group__group__ble__common__api__macros__section.html',1,'']]]
];
