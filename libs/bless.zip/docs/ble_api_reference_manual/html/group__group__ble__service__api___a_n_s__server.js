var group__group__ble__service__api___a_n_s__server =
[
    [ "Cy_BLE_ANSS_SetCharacteristicValue", "group__group__ble__service__api___a_n_s__server.html#ga1b4314234dc52710a971e6fdd44fe0b9", null ],
    [ "Cy_BLE_ANSS_GetCharacteristicValue", "group__group__ble__service__api___a_n_s__server.html#ga0122b84fa0ab874d8d2e40d2d1600f3a", null ],
    [ "Cy_BLE_ANSS_GetCharacteristicDescriptor", "group__group__ble__service__api___a_n_s__server.html#gac4367f299dc6bf69e5932309e4367eee", null ],
    [ "Cy_BLE_ANSS_SendNotification", "group__group__ble__service__api___a_n_s__server.html#gaeed39f38a1c48751cc995d1589f29033", null ]
];