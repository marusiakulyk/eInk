var group__group__ble__service__api___h_i_d_s__server__client =
[
    [ "Cy_BLE_HIDSS_Init", "group__group__ble__service__api___h_i_d_s__server__client.html#ga6c96b83c30c4faacc4feae860761094b", null ],
    [ "Cy_BLE_HIDSC_Init", "group__group__ble__service__api___h_i_d_s__server__client.html#ga75878d60a2eba521e80c71deeb6f1009", null ],
    [ "Cy_BLE_HIDS_RegisterAttrCallback", "group__group__ble__service__api___h_i_d_s__server__client.html#ga2d51dd0e954a980c1ed095d47ee055cc", null ]
];