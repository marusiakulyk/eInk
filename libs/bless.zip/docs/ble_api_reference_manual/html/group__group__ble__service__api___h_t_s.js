var group__group__ble__service__api___h_t_s =
[
    [ "HTS Server and Client Function", "group__group__ble__service__api___h_t_s__server__client.html", "group__group__ble__service__api___h_t_s__server__client" ],
    [ "HTS Server Functions", "group__group__ble__service__api___h_t_s__server.html", "group__group__ble__service__api___h_t_s__server" ],
    [ "HTS Client Functions", "group__group__ble__service__api___h_t_s__client.html", "group__group__ble__service__api___h_t_s__client" ],
    [ "HTS Definitions and Data Structures", "group__group__ble__service__api___h_t_s__definitions.html", "group__group__ble__service__api___h_t_s__definitions" ]
];