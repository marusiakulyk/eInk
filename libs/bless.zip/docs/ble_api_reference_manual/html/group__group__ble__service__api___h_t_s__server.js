var group__group__ble__service__api___h_t_s__server =
[
    [ "Cy_BLE_HTSS_SetCharacteristicValue", "group__group__ble__service__api___h_t_s__server.html#gad922b2d91c8b41f0ce5da208ff8872ea", null ],
    [ "Cy_BLE_HTSS_GetCharacteristicValue", "group__group__ble__service__api___h_t_s__server.html#ga4e222f5efc1a854fad860147a0de72b9", null ],
    [ "Cy_BLE_HTSS_SetCharacteristicDescriptor", "group__group__ble__service__api___h_t_s__server.html#ga8321a968f76e6f39cef7d58575483b45", null ],
    [ "Cy_BLE_HTSS_GetCharacteristicDescriptor", "group__group__ble__service__api___h_t_s__server.html#ga67a664f90d5f4c908d3204c7bda65cfb", null ],
    [ "Cy_BLE_HTSS_SendNotification", "group__group__ble__service__api___h_t_s__server.html#ga23284504bf3fbce53c320978723c8540", null ],
    [ "Cy_BLE_HTSS_SendIndication", "group__group__ble__service__api___h_t_s__server.html#ga6003df71f5a5c1fcbd2064a629392053", null ]
];