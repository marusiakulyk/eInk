var group__group__ble__service__api___c_g_m_s =
[
    [ "CGMS Server and Client Function", "group__group__ble__service__api___c_g_m_s__server__client.html", "group__group__ble__service__api___c_g_m_s__server__client" ],
    [ "CGMS Server Functions", "group__group__ble__service__api___c_g_m_s__server.html", "group__group__ble__service__api___c_g_m_s__server" ],
    [ "CGMS Client Functions", "group__group__ble__service__api___c_g_m_s__client.html", "group__group__ble__service__api___c_g_m_s__client" ],
    [ "CGMS Definitions and Data Structures", "group__group__ble__service__api___c_g_m_s__definitions.html", "group__group__ble__service__api___c_g_m_s__definitions" ]
];