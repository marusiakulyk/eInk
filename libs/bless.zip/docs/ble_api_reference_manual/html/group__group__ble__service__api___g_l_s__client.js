var group__group__ble__service__api___g_l_s__client =
[
    [ "Cy_BLE_GLSC_SetCharacteristicValue", "group__group__ble__service__api___g_l_s__client.html#ga5ae8b5951789f1e112fa89655bf3cb24", null ],
    [ "Cy_BLE_GLSC_GetCharacteristicValue", "group__group__ble__service__api___g_l_s__client.html#gaf4a8c475a20409f38fa5413e44f598b0", null ],
    [ "Cy_BLE_GLSC_SetCharacteristicDescriptor", "group__group__ble__service__api___g_l_s__client.html#gaedc5d92af9088ec3202cfb7c5c1a015d", null ],
    [ "Cy_BLE_GLSC_GetCharacteristicDescriptor", "group__group__ble__service__api___g_l_s__client.html#ga716b8b9e0408994e223a0dd978a9dd56", null ]
];