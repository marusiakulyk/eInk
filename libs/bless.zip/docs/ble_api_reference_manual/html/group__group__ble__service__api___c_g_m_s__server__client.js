var group__group__ble__service__api___c_g_m_s__server__client =
[
    [ "Cy_BLE_CGMSS_Init", "group__group__ble__service__api___c_g_m_s__server__client.html#ga92e60e72dacd0237aa35e4d525ce6393", null ],
    [ "Cy_BLE_CGMSC_Init", "group__group__ble__service__api___c_g_m_s__server__client.html#ga4c814c0f359d7a15876790c9ad27a615", null ],
    [ "Cy_BLE_CGMS_RegisterAttrCallback", "group__group__ble__service__api___c_g_m_s__server__client.html#gab298f6cc6a31558f29fdaf6ae4680504", null ]
];