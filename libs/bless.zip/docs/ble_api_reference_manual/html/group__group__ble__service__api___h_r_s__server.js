var group__group__ble__service__api___h_r_s__server =
[
    [ "Cy_BLE_HRSS_SetCharacteristicValue", "group__group__ble__service__api___h_r_s__server.html#ga53eb756e0c1732549ea6fb7fe7df32f8", null ],
    [ "Cy_BLE_HRSS_GetCharacteristicValue", "group__group__ble__service__api___h_r_s__server.html#ga9b724eb62361a9e17a8391ebd4329109", null ],
    [ "Cy_BLE_HRSS_GetCharacteristicDescriptor", "group__group__ble__service__api___h_r_s__server.html#ga268ce65e65d287a9b5b073c683cf05da", null ],
    [ "Cy_BLE_HRSS_SendNotification", "group__group__ble__service__api___h_r_s__server.html#ga855570ad54e2d57fbc59f1cc526fdd97", null ]
];