var group__group__ble__service__api___c_g_m_s__server =
[
    [ "Cy_BLE_CGMSS_SetCharacteristicValue", "group__group__ble__service__api___c_g_m_s__server.html#ga8dc67596b7839a312787e450a2df6714", null ],
    [ "Cy_BLE_CGMSS_GetCharacteristicValue", "group__group__ble__service__api___c_g_m_s__server.html#ga301d71b285e884eb76f019046ef14091", null ],
    [ "Cy_BLE_CGMSS_SetCharacteristicDescriptor", "group__group__ble__service__api___c_g_m_s__server.html#gabf005cecf36d32c38fa5d05a1a4e7ad0", null ],
    [ "Cy_BLE_CGMSS_GetCharacteristicDescriptor", "group__group__ble__service__api___c_g_m_s__server.html#ga6392ca22dd7e7ed3491cf32cfa2f0e90", null ],
    [ "Cy_BLE_CGMSS_SendNotification", "group__group__ble__service__api___c_g_m_s__server.html#ga62d0b3705bb0a685a86bdf5dc2d61c0d", null ],
    [ "Cy_BLE_CGMSS_SendIndication", "group__group__ble__service__api___c_g_m_s__server.html#gaf3d20a069a764f4324dfd8d130b4ed12", null ]
];