var group__group__ble__service__api___l_l_s__server__client =
[
    [ "Cy_BLE_LLSS_Init", "group__group__ble__service__api___l_l_s__server__client.html#ga748392c8e5e063de1cda8d26eb3d832a", null ],
    [ "Cy_BLE_LLSC_Init", "group__group__ble__service__api___l_l_s__server__client.html#ga7bcb2d2ad3832e5891cd83ebbb7f6960", null ],
    [ "Cy_BLE_LLS_RegisterAttrCallback", "group__group__ble__service__api___l_l_s__server__client.html#gaf76a6b80b1b7468d6e671f1968dbc6af", null ]
];