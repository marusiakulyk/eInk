var group__group__ble__service__api___h_i_d_s__server =
[
    [ "Cy_BLE_HIDSS_SetCharacteristicValue", "group__group__ble__service__api___h_i_d_s__server.html#ga9d4b2c2fd0a053eec375c8ec8c751e09", null ],
    [ "Cy_BLE_HIDSS_GetCharacteristicValue", "group__group__ble__service__api___h_i_d_s__server.html#ga8cdbcc38354ac0c065ec9de7f03b27f9", null ],
    [ "Cy_BLE_HIDSS_GetCharacteristicDescriptor", "group__group__ble__service__api___h_i_d_s__server.html#ga2ef320fe21c1bc6f9bd28d845c363f26", null ],
    [ "Cy_BLE_HIDSS_SendNotification", "group__group__ble__service__api___h_i_d_s__server.html#ga8ec18c732bc22c0d23f3386592b06bb4", null ]
];