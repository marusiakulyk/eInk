var group__group__ble__service__api___b_m_s__client =
[
    [ "Cy_BLE_BMSC_GetCharacteristicValue", "group__group__ble__service__api___b_m_s__client.html#gac9b16afdb62f9c1419108a1ff6f489a3", null ],
    [ "Cy_BLE_BMSC_SetCharacteristicValue", "group__group__ble__service__api___b_m_s__client.html#ga4a55b19529de9bb6d639f8c0309c174a", null ],
    [ "Cy_BLE_BMSC_ReliableWriteCharacteristicValue", "group__group__ble__service__api___b_m_s__client.html#gaa73b421673cf25dc7df11c2ea582f6ae", null ],
    [ "Cy_BLE_BMSC_GetCharacteristicDescriptor", "group__group__ble__service__api___b_m_s__client.html#ga039316c7004067a5665141d8a686dd56", null ]
];