var group__group__ble__service__api___c_p_s__server__client =
[
    [ "Cy_BLE_CPSS_Init", "group__group__ble__service__api___c_p_s__server__client.html#ga21b1ed2ffa3b48b376c0eab83b42554a", null ],
    [ "Cy_BLE_CPSC_Init", "group__group__ble__service__api___c_p_s__server__client.html#ga1e733092c67130ea3195b04cd65dae3b", null ],
    [ "Cy_BLE_CPS_RegisterAttrCallback", "group__group__ble__service__api___c_p_s__server__client.html#ga3bb034fe377f65e491205bc2aae1ee1d", null ]
];