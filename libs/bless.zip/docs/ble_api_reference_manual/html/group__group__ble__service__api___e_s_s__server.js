var group__group__ble__service__api___e_s_s__server =
[
    [ "Cy_BLE_ESSS_SetChangeIndex", "group__group__ble__service__api___e_s_s__server.html#ga2e73abd9c96d118a86882ba6c095e1d2", null ],
    [ "Cy_BLE_ESSS_SetCharacteristicValue", "group__group__ble__service__api___e_s_s__server.html#ga34ed9d47fa3800652dd8057263e8a46e", null ],
    [ "Cy_BLE_ESSS_GetCharacteristicValue", "group__group__ble__service__api___e_s_s__server.html#ga5ad1badfdbcdbb4fbf75e2fe360736fa", null ],
    [ "Cy_BLE_ESSS_SetCharacteristicDescriptor", "group__group__ble__service__api___e_s_s__server.html#gabb3f2be0e58a14ed287cfbefbc4b0d48", null ],
    [ "Cy_BLE_ESSS_GetCharacteristicDescriptor", "group__group__ble__service__api___e_s_s__server.html#ga3821e41759857924aef887030486fb5c", null ],
    [ "Cy_BLE_ESSS_SendNotification", "group__group__ble__service__api___e_s_s__server.html#gadb4beb380776cb400ea61edc2f6a5c0c", null ],
    [ "Cy_BLE_ESSS_SendIndication", "group__group__ble__service__api___e_s_s__server.html#gac11699db2b2f8dcc06cf7e0e622a4af3", null ]
];