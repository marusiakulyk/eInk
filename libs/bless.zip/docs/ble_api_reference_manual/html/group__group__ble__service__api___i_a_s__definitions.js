var group__group__ble__service__api___i_a_s__definitions =
[
    [ "cy_stc_ble_iass_t", "structcy__stc__ble__iass__t.html", [
      [ "serviceHandle", "structcy__stc__ble__iass__t.html#a0e77438783d4448d4a4732167dc5ddf7", null ],
      [ "alertLevelCharHandle", "structcy__stc__ble__iass__t.html#a35a0c758b7c5089c178944464f442b50", null ]
    ] ],
    [ "cy_stc_ble_ias_char_value_t", "structcy__stc__ble__ias__char__value__t.html", [
      [ "connHandle", "structcy__stc__ble__ias__char__value__t.html#a8be10333995d4a0035543c640454e8ee", null ],
      [ "charIndex", "structcy__stc__ble__ias__char__value__t.html#a42157fc28566463695d11e7b069ca09e", null ],
      [ "value", "structcy__stc__ble__ias__char__value__t.html#a3fbf2ea3d0c36523ab6f7e7c44192f6a", null ]
    ] ],
    [ "cy_stc_ble_iasc_t", "structcy__stc__ble__iasc__t.html", [
      [ "alertLevelChar", "structcy__stc__ble__iasc__t.html#a8bab8a8f4956959d124cc4b49756d6a7", null ]
    ] ],
    [ "cy_stc_ble_iass_config_t", "structcy__stc__ble__iass__config__t.html", [
      [ "attrInfo", "structcy__stc__ble__iass__config__t.html#a7b0f80f9f538c25353a5c0c704eadf6f", null ]
    ] ],
    [ "cy_stc_ble_iasc_config_t", "structcy__stc__ble__iasc__config__t.html", [
      [ "attrInfo", "structcy__stc__ble__iasc__config__t.html#a551d32ac275a28e4ba85ca7fcbec60f9", null ],
      [ "serviceDiscIdx", "structcy__stc__ble__iasc__config__t.html#ac86634027d0ef5af81604f5a16f7f60c", null ]
    ] ],
    [ "cy_en_ble_ias_char_index_t", "group__group__ble__service__api___i_a_s__definitions.html#gad27f470965bbd7e1938ef52ec411d11f", [
      [ "CY_BLE_IAS_ALERT_LEVEL", "group__group__ble__service__api___i_a_s__definitions.html#ggad27f470965bbd7e1938ef52ec411d11fa0e8d27cc4a06ffa0a7f27cea77a0aa1f", null ],
      [ "CY_BLE_IAS_CHAR_COUNT", "group__group__ble__service__api___i_a_s__definitions.html#ggad27f470965bbd7e1938ef52ec411d11fa849ccebe51cb6655eeb0752dd9da9ac2", null ]
    ] ]
];