var group__group__ble__service__api___a_n_c_s__client =
[
    [ "Cy_BLE_ANCSC_SetCharacteristicValue", "group__group__ble__service__api___a_n_c_s__client.html#gadf96ba036c26517db7da7011670c957c", null ],
    [ "Cy_BLE_ANCSC_SetCharacteristicDescriptor", "group__group__ble__service__api___a_n_c_s__client.html#ga0123290a9393dca4589b84b5f2f2fb08", null ],
    [ "Cy_BLE_ANCSC_GetCharacteristicDescriptor", "group__group__ble__service__api___a_n_c_s__client.html#ga22c26ff6a2af6e3c350128a348be390e", null ]
];