var group__group__ble__service__api___h_t_s__server__client =
[
    [ "Cy_BLE_HTSS_Init", "group__group__ble__service__api___h_t_s__server__client.html#ga25cea6cd35f111f8ba6d44d434d46375", null ],
    [ "Cy_BLE_HTSC_Init", "group__group__ble__service__api___h_t_s__server__client.html#ga31a614b841410841685e5c308ee8e6e9", null ],
    [ "Cy_BLE_HTS_RegisterAttrCallback", "group__group__ble__service__api___h_t_s__server__client.html#ga08529877d78fd8977c1896c33c0e688e", null ]
];