var group__group__ble__service__api___h_p_s__server =
[
    [ "Cy_BLE_HPSS_SetCharacteristicValue", "group__group__ble__service__api___h_p_s__server.html#ga9b664e9f10c80736693a876122d434d9", null ],
    [ "Cy_BLE_HPSS_GetCharacteristicValue", "group__group__ble__service__api___h_p_s__server.html#gaf89ff45d87b6e18380891a3960de0099", null ],
    [ "Cy_BLE_HPSS_SetCharacteristicDescriptor", "group__group__ble__service__api___h_p_s__server.html#ga95af48d3d6034ccf866349b252f38077", null ],
    [ "Cy_BLE_HPSS_GetCharacteristicDescriptor", "group__group__ble__service__api___h_p_s__server.html#gab45832abe1b4c6cdaf4d8cbece960e0a", null ],
    [ "Cy_BLE_HPSS_SendNotification", "group__group__ble__service__api___h_p_s__server.html#gadd302a42ede583c7e786dd1984fd24d9", null ]
];