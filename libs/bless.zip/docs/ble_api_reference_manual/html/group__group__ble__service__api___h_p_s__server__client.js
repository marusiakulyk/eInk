var group__group__ble__service__api___h_p_s__server__client =
[
    [ "Cy_BLE_HPSS_Init", "group__group__ble__service__api___h_p_s__server__client.html#gae470b9787d6b9396d585ef737969f54b", null ],
    [ "Cy_BLE_HPSC_Init", "group__group__ble__service__api___h_p_s__server__client.html#ga88a8d0d0501936a350dfe656aa5ddace", null ],
    [ "Cy_BLE_HPS_RegisterAttrCallback", "group__group__ble__service__api___h_p_s__server__client.html#gaadebeb6b9194ad8dba80581a300e28a0", null ]
];