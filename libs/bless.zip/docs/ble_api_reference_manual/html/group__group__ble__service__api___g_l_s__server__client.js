var group__group__ble__service__api___g_l_s__server__client =
[
    [ "Cy_BLE_GLSS_Init", "group__group__ble__service__api___g_l_s__server__client.html#ga4807a112e9335859de8f0172c5e3cccd", null ],
    [ "Cy_BLE_GLSC_Init", "group__group__ble__service__api___g_l_s__server__client.html#gaf155bc7a3ff5a1620045149c90e6eeb9", null ],
    [ "Cy_BLE_GLS_RegisterAttrCallback", "group__group__ble__service__api___g_l_s__server__client.html#ga4922528c4a3ea7e681368ffd44c86881", null ]
];