var group__group__ble__service__api___b_c_s__server__client =
[
    [ "Cy_BLE_BCSS_Init", "group__group__ble__service__api___b_c_s__server__client.html#gadd6edddc3893e6a0eb13d2409fc6ed12", null ],
    [ "Cy_BLE_BCSC_Init", "group__group__ble__service__api___b_c_s__server__client.html#ga6a35d17b0b0538477acea07a77e05991", null ],
    [ "Cy_BLE_BCS_RegisterAttrCallback", "group__group__ble__service__api___b_c_s__server__client.html#gabb6351313978c2bd0bd466693dabcc5d", null ]
];