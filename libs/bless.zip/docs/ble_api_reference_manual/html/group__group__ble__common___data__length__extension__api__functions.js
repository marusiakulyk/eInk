var group__group__ble__common___data__length__extension__api__functions =
[
    [ "Cy_BLE_GetDataLength", "group__group__ble__common___data__length__extension__api__functions.html#gad7b48609c738eb9feed41eea82e03728", null ]
];