var group__group__ble__service__api___a_n_s__client =
[
    [ "Cy_BLE_ANSC_GetCharacteristicValue", "group__group__ble__service__api___a_n_s__client.html#gab9ce050718a1b37ce77632fc631ab464", null ],
    [ "Cy_BLE_ANSC_SetCharacteristicValue", "group__group__ble__service__api___a_n_s__client.html#ga567fc24fa83c1c9723d9cf00fcdce955", null ],
    [ "Cy_BLE_ANSC_SetCharacteristicDescriptor", "group__group__ble__service__api___a_n_s__client.html#ga67a5da9249162633bbf73f9dc3691a5a", null ],
    [ "Cy_BLE_ANSC_GetCharacteristicDescriptor", "group__group__ble__service__api___a_n_s__client.html#ga83f239224b90e7ebb7e067513c59f25b", null ]
];