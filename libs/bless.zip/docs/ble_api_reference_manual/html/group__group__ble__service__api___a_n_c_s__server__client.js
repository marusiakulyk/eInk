var group__group__ble__service__api___a_n_c_s__server__client =
[
    [ "Cy_BLE_ANCSS_Init", "group__group__ble__service__api___a_n_c_s__server__client.html#ga92382476955712c4bd53acd1a429b1b8", null ],
    [ "Cy_BLE_ANCSC_Init", "group__group__ble__service__api___a_n_c_s__server__client.html#gac8c98d6ec237ff994e9da4eeca4fa35a", null ],
    [ "Cy_BLE_ANCS_RegisterAttrCallback", "group__group__ble__service__api___a_n_c_s__server__client.html#ga4e932b792998583ac5172917b97928af", null ]
];