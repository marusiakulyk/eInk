var group__group__ble__service__api___d_i_s__server =
[
    [ "Cy_BLE_DISS_SetCharacteristicValue", "group__group__ble__service__api___d_i_s__server.html#ga268f368d67b91ec9bbb7b4e3d3aee78a", null ],
    [ "Cy_BLE_DISS_GetCharacteristicValue", "group__group__ble__service__api___d_i_s__server.html#ga7f07ea4839a5a73570857290dc509bf7", null ]
];