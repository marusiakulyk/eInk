var group__group__ble__service__api___a_i_o_s =
[
    [ "AIOS Server and Client Function", "group__group__ble__service__api___a_i_o_s__server__client.html", "group__group__ble__service__api___a_i_o_s__server__client" ],
    [ "AIOS Server Functions", "group__group__ble__service__api___a_i_o_s__server.html", "group__group__ble__service__api___a_i_o_s__server" ],
    [ "AIOS Client Functions", "group__group__ble__service__api___a_i_o_s__client.html", "group__group__ble__service__api___a_i_o_s__client" ],
    [ "AIOS Definitions and Data Structures", "group__group__ble__service__api___a_i_o_s__definitions.html", "group__group__ble__service__api___a_i_o_s__definitions" ]
];