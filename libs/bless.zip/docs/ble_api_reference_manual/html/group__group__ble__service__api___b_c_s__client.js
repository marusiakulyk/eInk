var group__group__ble__service__api___b_c_s__client =
[
    [ "Cy_BLE_BCSC_GetCharacteristicValue", "group__group__ble__service__api___b_c_s__client.html#gad0a2743c95f78874784b269a3e439ca8", null ],
    [ "Cy_BLE_BCSC_SetCharacteristicDescriptor", "group__group__ble__service__api___b_c_s__client.html#gada9cc19e68ddf3dc88999a0eb4bc4e1c", null ],
    [ "Cy_BLE_BCSC_GetCharacteristicDescriptor", "group__group__ble__service__api___b_c_s__client.html#gaf25bb65e3c191afe9f11fbf9a10a1c23", null ]
];