var group__group__ble__common__api__macros__gatt__uuid__char__desc =
[
    [ "CY_BLE_UUID_CHAR_EXTENDED_PROPERTIES", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#gad26eb2e405e3eb95caabb454af879321", null ],
    [ "CY_BLE_UUID_CHAR_USER_DESCRIPTION", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#ga994ab5a1152fc70e814759c7e85c393b", null ],
    [ "CY_BLE_UUID_CHAR_CLIENT_CONFIG", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#ga6a2d110d472c61c2444af0489f4a54d3", null ],
    [ "CY_BLE_UUID_CHAR_SERVER_CONFIG", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#ga824ef49ded9c4a4903449039be92067f", null ],
    [ "CY_BLE_UUID_CHAR_FORMAT", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#ga68b3577db1bca8b7df02649d5bee293a", null ],
    [ "CY_BLE_UUID_CHAR_AGGREGATE_FORMAT", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#ga86d40573714350b8d2ffca7d1d3b22d1", null ],
    [ "CY_BLE_UUID_CHAR_VALID_RANGE", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#ga824b567b10a51351ca9c4cb05e9570c5", null ],
    [ "CY_BLE_UUID_CHAR_EXTERNAL_REPORT_REF", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#gaa730e18f67d89c7a8daac3cc59bee8f5", null ],
    [ "CY_BLE_UUID_CHAR_REPORT_REFERENCE", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#ga28138c8767fe4b3a21acbeadb59d2064", null ],
    [ "CY_BLE_UUID_CHAR_NUMBER_OF_DIGITALS", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#gad886f03bbeea15a356401f2a13f99950", null ],
    [ "CY_BLE_UUID_CHAR_VALUE_TRIGGER_SETTING", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#ga4ebee5d36802c0eb110e8832e81f13e8", null ],
    [ "CY_BLE_UUID_CHAR_ES_CONFIGURATION", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#gaef0b91144ac2d192048d15c7c0a006c5", null ],
    [ "CY_BLE_UUID_CHAR_ES_MEASUREMENT", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#gad0f97efd149278ff35d92a08ef2d0ea8", null ],
    [ "CY_BLE_UUID_CHAR_ES_TRIGGER_SETTING", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#ga31577da5c19fff6b827cde6bdb8cee83", null ],
    [ "CY_BLE_UUID_CHAR_TIME_TRIGGER_SETTING", "group__group__ble__common__api__macros__gatt__uuid__char__desc.html#ga7a55eec592e7440b6dd04f6c4265ed2e", null ]
];