var group__group__ble__service__api___h_p_s =
[
    [ "HPS Server and Client Function", "group__group__ble__service__api___h_p_s__server__client.html", "group__group__ble__service__api___h_p_s__server__client" ],
    [ "HPS Server Functions", "group__group__ble__service__api___h_p_s__server.html", "group__group__ble__service__api___h_p_s__server" ],
    [ "HPS Client Functions", "group__group__ble__service__api___h_p_s__client.html", "group__group__ble__service__api___h_p_s__client" ],
    [ "HPS Definitions and Data Structures", "group__group__ble__service__api___h_p_s__definitions.html", "group__group__ble__service__api___h_p_s__definitions" ]
];