var group__group__ble__service__api___d_i_s__server__client =
[
    [ "Cy_BLE_DISS_Init", "group__group__ble__service__api___d_i_s__server__client.html#ga18c826e11e5e430f89df77ab2d0caa34", null ],
    [ "Cy_BLE_DISC_Init", "group__group__ble__service__api___d_i_s__server__client.html#ga6aa2362e8cf51fb452beef70d922382d", null ],
    [ "Cy_BLE_DIS_RegisterAttrCallback", "group__group__ble__service__api___d_i_s__server__client.html#ga732171c25637b7c95c814b48c1c6d115", null ]
];