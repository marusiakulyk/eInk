var group__group__ble__service__api___l_n_s__server =
[
    [ "Cy_BLE_LNSS_SetCharacteristicValue", "group__group__ble__service__api___l_n_s__server.html#gab8480b308c065d6d3deca8d34e0be947", null ],
    [ "Cy_BLE_LNSS_GetCharacteristicValue", "group__group__ble__service__api___l_n_s__server.html#ga4376572033118dcc825227d2b1dbe617", null ],
    [ "Cy_BLE_LNSS_GetCharacteristicDescriptor", "group__group__ble__service__api___l_n_s__server.html#ga8ab4716466e525d94144fd3bbe5101f0", null ],
    [ "Cy_BLE_LNSS_SendNotification", "group__group__ble__service__api___l_n_s__server.html#ga69b2123aa4b2b3418a66e78f4069883a", null ],
    [ "Cy_BLE_LNSS_SendIndication", "group__group__ble__service__api___l_n_s__server.html#gaeb034308b1567034d604c2b324c8e307", null ]
];