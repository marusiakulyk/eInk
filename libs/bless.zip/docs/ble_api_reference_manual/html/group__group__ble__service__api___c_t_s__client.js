var group__group__ble__service__api___c_t_s__client =
[
    [ "Cy_BLE_CTSC_SetCharacteristicValue", "group__group__ble__service__api___c_t_s__client.html#gaac2bdf801943ab8ebbc5c7edba63f6b7", null ],
    [ "Cy_BLE_CTSC_GetCharacteristicValue", "group__group__ble__service__api___c_t_s__client.html#ga10ef7623a4d24288fa7f4888c7d757c3", null ],
    [ "Cy_BLE_CTSC_SetCharacteristicDescriptor", "group__group__ble__service__api___c_t_s__client.html#ga935941dd8677348f1b0c743657050fa0", null ],
    [ "Cy_BLE_CTSC_GetCharacteristicDescriptor", "group__group__ble__service__api___c_t_s__client.html#gaeff9182394de09e361ccdd9a3de4f53b", null ]
];