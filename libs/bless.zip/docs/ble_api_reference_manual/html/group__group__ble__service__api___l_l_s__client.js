var group__group__ble__service__api___l_l_s__client =
[
    [ "Cy_BLE_LLSC_SetCharacteristicValue", "group__group__ble__service__api___l_l_s__client.html#ga32ecec6d0f500469b25e9aa06a07f1a4", null ],
    [ "Cy_BLE_LLSC_GetCharacteristicValue", "group__group__ble__service__api___l_l_s__client.html#ga7f283bf10b9152030aae9d35a4d13f30", null ]
];