var group__group__ble__service__api___b_a_s__client =
[
    [ "Cy_BLE_BASC_GetCharacteristicValue", "group__group__ble__service__api___b_a_s__client.html#ga5216baab36e7e6a08c6e842fcf56e854", null ],
    [ "Cy_BLE_BASC_SetCharacteristicDescriptor", "group__group__ble__service__api___b_a_s__client.html#gadf672c32644d1032545ceaebfcb1528d", null ],
    [ "Cy_BLE_BASC_GetCharacteristicDescriptor", "group__group__ble__service__api___b_a_s__client.html#gafa54e1f2f2dc41097ed52421bd1dce40", null ]
];