var group__group__ble__service__api___h_r_s__client =
[
    [ "Cy_BLE_HRSC_SetCharacteristicValue", "group__group__ble__service__api___h_r_s__client.html#ga9b2cb534cb6d57a1ff1d1cd407430bca", null ],
    [ "Cy_BLE_HRSC_GetCharacteristicValue", "group__group__ble__service__api___h_r_s__client.html#ga19169dd3e9d881ca240465c715ce9d30", null ],
    [ "Cy_BLE_HRSC_SetCharacteristicDescriptor", "group__group__ble__service__api___h_r_s__client.html#ga2e2b6726e96fe3da591e5d08d56be4ab", null ],
    [ "Cy_BLE_HRSC_GetCharacteristicDescriptor", "group__group__ble__service__api___h_r_s__client.html#ga01d3bc9aeaf7c8e5a9a05c959f21842f", null ]
];