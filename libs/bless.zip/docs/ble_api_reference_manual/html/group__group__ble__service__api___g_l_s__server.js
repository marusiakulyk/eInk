var group__group__ble__service__api___g_l_s__server =
[
    [ "Cy_BLE_GLSS_SetCharacteristicValue", "group__group__ble__service__api___g_l_s__server.html#ga5f3871432442654faebf221ba2aeff4f", null ],
    [ "Cy_BLE_GLSS_GetCharacteristicValue", "group__group__ble__service__api___g_l_s__server.html#ga00df8a17aade970157f9ec2c287a6f6c", null ],
    [ "Cy_BLE_GLSS_GetCharacteristicDescriptor", "group__group__ble__service__api___g_l_s__server.html#ga86e4b02143a0b57d10ef0d2e24b5f619", null ],
    [ "Cy_BLE_GLSS_SendNotification", "group__group__ble__service__api___g_l_s__server.html#ga0d6946e7a398d4d0e6f6a1fe829a6c0e", null ],
    [ "Cy_BLE_GLSS_SendIndication", "group__group__ble__service__api___g_l_s__server.html#ga68656f0392f4e6c49828180c68fcb309", null ]
];