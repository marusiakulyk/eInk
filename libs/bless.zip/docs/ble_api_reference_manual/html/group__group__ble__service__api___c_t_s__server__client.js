var group__group__ble__service__api___c_t_s__server__client =
[
    [ "Cy_BLE_CTSS_Init", "group__group__ble__service__api___c_t_s__server__client.html#ga86467260cac23f707f18317c6dc599c0", null ],
    [ "Cy_BLE_CTSC_Init", "group__group__ble__service__api___c_t_s__server__client.html#ga1c9ba0f9564a766cff2cad9616d01c22", null ],
    [ "Cy_BLE_CTS_RegisterAttrCallback", "group__group__ble__service__api___c_t_s__server__client.html#gacd687f278ad25b555e9016f4a4aa0eb7", null ]
];