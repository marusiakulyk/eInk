var group__group__ble__service__api___d_i_s__client =
[
    [ "Cy_BLE_DISC_GetCharacteristicValue", "group__group__ble__service__api___d_i_s__client.html#ga0c01855447ff6fddb704ee34ecc7588d", null ]
];